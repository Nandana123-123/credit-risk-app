import { Helmet } from "react-helmet-async";

const endpoints = [
  { method: 'POST', path: '/auth', actions: ['setup-password', 'verify-password', 'forgot-password', 'change-password'], desc: 'Security password management' },
  { method: 'POST', path: '/transaction', actions: ['analyze', 'execute'], desc: 'AMFIS fraud analysis & execution' },
  { method: 'GET/POST', path: '/fraud', actions: ['explain', 'replay', 'clusters', 'receiver-risk', 'digital-twin', 'rbi-compliance', 'red-team'], desc: 'Forensics & admin APIs' },
];

const Index = () => {
  return (
    <>
      <Helmet>
        <title>RakshaPay AI - UPI Fraud Prevention Backend</title>
        <meta name="description" content="Production-grade simulated backend for next-gen UPI fraud prevention using AMFIS" />
      </Helmet>
      <div className="min-h-screen bg-background text-foreground p-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold text-primary mb-2">🛡️ RakshaPay AI</h1>
            <p className="text-xl text-muted-foreground">Adaptive Multi-Layer Fraud Intelligence System (AMFIS)</p>
            <p className="text-sm text-muted-foreground mt-2">Block Fraud Before Money Is Lost</p>
          </div>
          
          <div className="bg-card border border-border rounded-lg p-6 mb-6">
            <h2 className="text-2xl font-semibold mb-4">🔌 API Endpoints</h2>
            <p className="text-sm text-muted-foreground mb-4">Base URL: <code className="bg-muted px-2 py-1 rounded">{`https://kxnhnwluwggnpifdgfud.supabase.co/functions/v1`}</code></p>
            
            <div className="space-y-4">
              {endpoints.map((ep, i) => (
                <div key={i} className="border border-border rounded p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-mono">{ep.method}</span>
                    <code className="text-sm font-mono">{ep.path}</code>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{ep.desc}</p>
                  <div className="flex flex-wrap gap-1">
                    {ep.actions.map(a => <span key={a} className="bg-muted text-xs px-2 py-1 rounded">{a}</span>)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-2xl font-semibold mb-4">🧠 AMFIS Modules</h2>
            <ul className="space-y-2 text-sm">
              <li>✅ <strong>Layer 1:</strong> Behavioral Biometrics Engine</li>
              <li>✅ <strong>Layer 2:</strong> Voice Deepfake Detection</li>
              <li>✅ <strong>Layer 3:</strong> NLP Scam Intent Detection</li>
              <li>✅ <strong>Layer 4:</strong> Device & Network Forensics</li>
              <li>✅ <strong>Layer 5:</strong> Transaction Graph Intelligence</li>
              <li>✅ <strong>Layer 6:</strong> Adaptive Risk Fusion Engine</li>
              <li>✅ <strong>Layer 7:</strong> Real-time Preventive Actions</li>
              <li>✅ <strong>Layer 8:</strong> Security Password System</li>
              <li>✅ <strong>Layer 9:</strong> Forensics & RBI Compliance</li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default Index;
