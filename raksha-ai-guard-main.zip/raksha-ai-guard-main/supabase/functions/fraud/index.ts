import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { corsHeaders, jsonResponse, errorResponse, handleCors } from "../_shared/cors.ts";
import { transactionHistory, fraudClusters, graphNodes, fraudsterProfiles, rbiComplianceMappings } from "../_shared/mock-database.ts";

serve(async (req) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action') || (await req.json().catch(() => ({}))).action;
    const txnId = url.searchParams.get('transactionId');
    console.log('[FRAUD_API] Action:', action);

    switch (action) {
      case 'explain': {
        const txn = transactionHistory.find(t => t.transactionId === txnId);
        if (!txn) return errorResponse('Transaction not found', 404);
        return jsonResponse({
          success: true,
          transactionId: txnId,
          explanation: {
            humanReadable: `This transaction was ${txn.status} because: ${txn.blockReasons.join('; ') || 'No issues detected'}`,
            featureAnalysis: Object.entries(txn.analysisBreakdown).filter(([k]) => k.endsWith('Score')).map(([k, v]) => ({ feature: k, value: v, exceeded: (v as number) > 40 })),
            aiConfidence: 87,
            blockReasons: txn.blockReasons
          }
        });
      }

      case 'replay': {
        const txn = transactionHistory.find(t => t.transactionId === txnId);
        if (!txn) return errorResponse('Transaction not found', 404);
        return jsonResponse({
          success: true,
          transactionId: txnId,
          timeline: [
            { step: 1, event: 'Transaction initiated', riskLevel: 0, aiAction: 'Monitoring started' },
            { step: 2, event: 'Behavioral analysis', riskLevel: txn.analysisBreakdown.behaviorScore, aiAction: 'Checked user patterns' },
            { step: 3, event: 'NLP scan complete', riskLevel: txn.analysisBreakdown.nlpScore, aiAction: 'Scanned messages' },
            { step: 4, event: 'Graph analysis', riskLevel: txn.analysisBreakdown.graphScore, aiAction: 'Checked receiver history' },
            { step: 5, event: 'Final decision', riskLevel: txn.finalRiskScore, aiAction: txn.status }
          ],
          finalOutcome: txn.status,
          preventedLoss: txn.status === 'BLOCKED' ? 15000 : 0
        });
      }

      case 'clusters':
        return jsonResponse({ success: true, clusters: fraudClusters, totalClusters: fraudClusters.length });

      case 'receiver-risk': {
        const upi = url.searchParams.get('upi') || '';
        const node = graphNodes.get(upi);
        return jsonResponse({ success: true, receiverUpi: upi, trustScore: node?.trustScore ?? 50, flaggedCount: node?.flaggedCount ?? 0, isKnown: !!node });
      }

      case 'digital-twin':
        return jsonResponse({ success: true, fraudsterProfiles, description: 'Simulated fraudster behavior evolution' });

      case 'rbi-compliance':
        return jsonResponse({ success: true, mappings: rbiComplianceMappings, complianceRate: '100%' });

      case 'red-team': {
        return jsonResponse({
          success: true,
          mode: 'RED_TEAM_ACTIVE',
          simulatedAttack: {
            type: 'Refund Scam + Deepfake Voice',
            targetProfile: 'Senior citizen, first-time UPI user',
            attackVector: 'Fake refund SMS → Deepfake call → Urgency pressure',
            expectedSuccessRate: '12%',
            defenseTriggered: ['NLP_SCAM_DETECTION', 'VOICE_DEEPFAKE_ALERT', 'PANIC_BEHAVIOR_FLAG']
          }
        });
      }

      default:
        return jsonResponse({
          success: true,
          message: 'RakshaPay AI Fraud API',
          endpoints: ['explain', 'replay', 'clusters', 'receiver-risk', 'digital-twin', 'rbi-compliance', 'red-team']
        });
    }
  } catch (error) {
    console.error('[FRAUD_API] Error:', error);
    return errorResponse(error instanceof Error ? error.message : 'Unknown error', 500);
  }
});
