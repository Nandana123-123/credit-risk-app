import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { corsHeaders, jsonResponse, errorResponse, handleCors } from "../_shared/cors.ts";
import { usersDB } from "../_shared/mock-database.ts";

serve(async (req) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  try {
    const { action, userId, password, newPassword } = await req.json();
    console.log('[AUTH_API] Action:', action, 'User:', userId);

    const user = usersDB.get(userId || 'user_001');
    if (!user) return errorResponse('User not found', 404);

    switch (action) {
      case 'setup-password':
        if (!password || password.length < 6) return errorResponse('Password must be 6+ characters', 400);
        user.passwordHash = `hashed_${password}`;
        user.isPasswordSet = true;
        user.passwordSetAt = new Date().toISOString();
        return jsonResponse({ success: true, message: 'Security password set successfully' });

      case 'verify-password':
        if (!user.isPasswordSet) return errorResponse('Password not set. Setup required first.', 400);
        const isValid = user.passwordHash === `hashed_${password}`;
        return jsonResponse({ success: isValid, message: isValid ? 'Password verified' : 'Invalid password', verified: isValid });

      case 'forgot-password':
        return jsonResponse({ success: true, message: 'OTP sent to registered mobile (simulated)', otpSentTo: user.phone.replace(/\d(?=\d{4})/g, '*') });

      case 'change-password':
        if (!user.isPasswordSet) return errorResponse('Setup password first', 400);
        if (user.passwordHash !== `hashed_${password}`) return errorResponse('Current password incorrect', 401);
        if (!newPassword || newPassword.length < 6) return errorResponse('New password must be 6+ characters', 400);
        user.passwordHash = `hashed_${newPassword}`;
        user.passwordSetAt = new Date().toISOString();
        return jsonResponse({ success: true, message: 'Password changed. 2FA verified (simulated).' });

      default:
        return errorResponse('Invalid action. Use: setup-password, verify-password, forgot-password, change-password', 400);
    }
  } catch (error) {
    console.error('[AUTH_API] Error:', error);
    return errorResponse(error instanceof Error ? error.message : 'Unknown error', 500);
  }
});
