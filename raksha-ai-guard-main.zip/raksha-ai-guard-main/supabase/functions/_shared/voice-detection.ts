// ============================================================
// RakshaPay AI - Voice Deepfake Detection (AMFIS Layer 2)
// Simulates AI-based voice analysis for fraud detection
// ============================================================

import type { VoiceAnalysis } from './types.ts';

// Simulated spectral analysis patterns
const DEEPFAKE_INDICATORS = {
  spectralFlattening: 0.7,       // AI voices tend to have flatter spectral curves
  pitchVariation: 0.3,          // Natural speech has more pitch variation
  breathingPatterns: 0.5,       // Real humans have natural breathing
  microPauses: 0.4,             // Natural speech has micro-pauses
  harmonicRichness: 0.6,        // Human voices have richer harmonics
  formantConsistency: 0.5       // AI may have inconsistent formants
};

// Known scam voice patterns (simulated fingerprints)
const KNOWN_SCAM_VOICES = new Set([
  'voice_fp_scam001',
  'voice_fp_scam002',
  'voice_fp_scam003'
]);

/**
 * Analyzes voice sample for deepfake/synthetic detection
 * Only triggered when callActive = true
 */
export function analyzeVoice(
  voiceSample: string | undefined,
  callActive: boolean
): VoiceAnalysis {
  console.log('[VOICE_ENGINE] Voice analysis triggered. Call active:', callActive);
  
  // If no call is active, return neutral result
  if (!callActive) {
    return {
      isHuman: true,
      isAIGenerated: false,
      classification: 'UNKNOWN',
      confidenceScore: 0,
      audioQuality: 'HIGH',
      spectralAnomaly: false
    };
  }
  
  // If call is active but no voice sample, flag as suspicious
  if (!voiceSample) {
    console.log('[VOICE_ENGINE] Call active but no voice sample provided');
    return {
      isHuman: false,
      isAIGenerated: false,
      classification: 'UNKNOWN',
      confidenceScore: 50,
      warningMessage: 'Voice sample not available for verification during active call',
      audioQuality: 'LOW',
      spectralAnomaly: false
    };
  }
  
  // Simulate voice analysis based on sample characteristics
  const analysis = simulateVoiceAnalysis(voiceSample);
  
  console.log('[VOICE_ENGINE] Analysis result:', JSON.stringify(analysis));
  return analysis;
}

/**
 * Simulates detailed voice analysis
 * In production, this would use actual ML models
 */
function simulateVoiceAnalysis(voiceSample: string): VoiceAnalysis {
  // Simulate analysis based on sample length and content
  // Using hash of sample to create deterministic results for demo
  const sampleHash = simpleHash(voiceSample);
  
  // Generate simulated metrics
  const spectralScore = (sampleHash % 100) / 100;
  const pitchScore = ((sampleHash >> 8) % 100) / 100;
  const breathingScore = ((sampleHash >> 16) % 100) / 100;
  
  // Simulate known scam voice detection
  const voiceFingerprint = `voice_fp_${(sampleHash % 1000).toString().padStart(3, '0')}`;
  const isKnownScamVoice = KNOWN_SCAM_VOICES.has(voiceFingerprint);
  
  // Calculate deepfake probability
  let deepfakeProbability = 0;
  
  // Check spectral anomalies (AI voices often have uniform spectral distribution)
  if (spectralScore > DEEPFAKE_INDICATORS.spectralFlattening) {
    deepfakeProbability += 25;
  }
  
  // Check pitch variation (AI voices may lack natural variation)
  if (pitchScore < DEEPFAKE_INDICATORS.pitchVariation) {
    deepfakeProbability += 20;
  }
  
  // Check breathing patterns (AI typically lacks natural breathing)
  if (breathingScore < DEEPFAKE_INDICATORS.breathingPatterns) {
    deepfakeProbability += 20;
  }
  
  // Known scam voice detection
  if (isKnownScamVoice) {
    deepfakeProbability += 35;
  }
  
  // Random factor for demo variability (15% variance)
  deepfakeProbability += (sampleHash % 15);
  
  // Cap at 100
  deepfakeProbability = Math.min(deepfakeProbability, 100);
  
  // Determine classification
  const isAIGenerated = deepfakeProbability > 50;
  const isHuman = deepfakeProbability < 30;
  
  let classification: VoiceAnalysis['classification'];
  if (deepfakeProbability >= 70) {
    classification = 'DEEPFAKE';
  } else if (deepfakeProbability >= 50) {
    classification = 'SYNTHETIC';
  } else if (deepfakeProbability < 30) {
    classification = 'HUMAN';
  } else {
    classification = 'UNKNOWN';
  }
  
  // Determine audio quality
  const audioQuality: VoiceAnalysis['audioQuality'] = 
    voiceSample.length > 1000 ? 'HIGH' : 
    voiceSample.length > 500 ? 'MEDIUM' : 'LOW';
  
  // Generate warning message if suspicious
  let warningMessage: string | undefined;
  if (classification === 'DEEPFAKE') {
    warningMessage = '⚠️ HIGH ALERT: AI-generated voice detected! This may be a scam call using voice cloning technology.';
  } else if (classification === 'SYNTHETIC') {
    warningMessage = '⚠️ WARNING: Voice shows synthetic characteristics. Exercise caution and verify caller identity.';
  } else if (isKnownScamVoice) {
    warningMessage = '⚠️ DANGER: Voice matches known scam caller profile!';
  }
  
  return {
    isHuman,
    isAIGenerated,
    classification,
    confidenceScore: Math.round(100 - Math.abs(deepfakeProbability - 50)),
    warningMessage,
    audioQuality,
    spectralAnomaly: spectralScore > DEEPFAKE_INDICATORS.spectralFlattening
  };
}

/**
 * Simple hash function for demo purposes
 */
function simpleHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

/**
 * Generates mock voice samples for testing
 */
export function generateMockVoiceSample(type: 'human' | 'deepfake' | 'synthetic'): string {
  const base = Date.now().toString(36);
  switch (type) {
    case 'deepfake':
      return `DEEPFAKE_SAMPLE_${base}_spectral_flat_no_breathing_low_pitch_variation`;
    case 'synthetic':
      return `SYNTHETIC_SAMPLE_${base}_partial_artifacts_some_breathing`;
    default:
      return `HUMAN_SAMPLE_${base}_natural_breathing_rich_harmonics_variable_pitch`;
  }
}

/**
 * Extracts voice risk score (0-100) for fusion engine
 */
export function getVoiceRiskScore(analysis: VoiceAnalysis): number {
  if (!analysis.confidenceScore) return 0;
  
  switch (analysis.classification) {
    case 'DEEPFAKE':
      return 90 + (analysis.confidenceScore / 10);
    case 'SYNTHETIC':
      return 60 + (analysis.confidenceScore / 5);
    case 'HUMAN':
      return Math.max(0, 10 - (analysis.confidenceScore / 10));
    default:
      return 30; // Unknown = moderate risk
  }
}
