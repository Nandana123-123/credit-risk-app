// ============================================================
// RakshaPay AI - Type Definitions
// Adaptive Multi-Layer Fraud Intelligence System (AMFIS)
// ============================================================

// ==================== USER & AUTH TYPES ====================
export interface User {
  userId: string;
  phone: string;
  email: string;
  name: string;
  passwordHash: string; // Simulated password storage
  passwordSetAt: string;
  isPasswordSet: boolean;
  createdAt: string;
  lastLogin: string;
  trustScore: number; // 0-100
  isBlocked: boolean;
  blockReason?: string;
}

export interface AuthSession {
  sessionId: string;
  userId: string;
  deviceId: string;
  createdAt: string;
  expiresAt: string;
  isPasswordVerified: boolean;
}

// ==================== DEVICE & LOCATION TYPES ====================
export interface DeviceInfo {
  deviceId: string;
  fingerprint: string;
  platform: string; // android, ios, web
  osVersion: string;
  appVersion: string;
  isEmulator: boolean;
  isRooted: boolean;
  lastSeen: string;
}

export interface LocationInfo {
  latitude: number;
  longitude: number;
  city: string;
  state: string;
  country: string;
  isVPN: boolean;
  isProxy: boolean;
  ipAddress: string;
}

// ==================== TRANSACTION TYPES ====================
export interface TransactionRequest {
  transactionId: string;
  senderId: string;
  senderPhone: string;
  receiverUpiId: string;
  receiverPhone?: string;
  receiverName?: string;
  amount: number;
  purpose?: string;
  timestamp: string;
  deviceInfo: DeviceInfo;
  locationInfo: LocationInfo;
  behaviorMetrics: BehaviorMetrics;
  callActive: boolean;
  voiceSample?: string; // Base64 encoded voice sample
  recentMessages?: string[]; // Recent SMS/notifications
}

export interface TransactionResult {
  transactionId: string;
  status: 'ALLOWED' | 'WARNING' | 'BLOCKED';
  finalRiskScore: number;
  riskCategory: 'GREEN' | 'YELLOW' | 'RED';
  blockReasons: string[];
  recommendedAction: string;
  analysisBreakdown: RiskBreakdown;
  timestamp: string;
  coolingOffSeconds?: number;
  requiresAdditionalVerification: boolean;
}

// ==================== BEHAVIORAL BIOMETRICS ====================
export interface BehaviorMetrics {
  clickSpeed: number; // clicks per second
  hesitationTime: number; // milliseconds
  rapidRetries: number;
  backAndForthNavigation: number;
  panicConfirmations: number;
  isNightTime: boolean;
  sessionDuration: number; // seconds
  typingSpeed: number; // chars per minute
  touchPressure?: number; // 0-1 normalized
  scrollVelocity?: number;
}

export interface BehaviorAnalysis {
  riskScore: number; // 0-100
  status: 'NORMAL' | 'ANOMALOUS';
  cognitiveLoadIndicator: 'CALM' | 'PRESSURED' | 'PANIC';
  anomalies: string[];
  confidence: number;
}

// ==================== VOICE DEEPFAKE DETECTION ====================
export interface VoiceAnalysis {
  isHuman: boolean;
  isAIGenerated: boolean;
  classification: 'HUMAN' | 'DEEPFAKE' | 'SYNTHETIC' | 'UNKNOWN';
  confidenceScore: number; // 0-100
  warningMessage?: string;
  audioQuality: 'HIGH' | 'MEDIUM' | 'LOW';
  spectralAnomaly: boolean;
}

// ==================== NLP SCAM DETECTION ====================
export interface ScamKeyword {
  phrase: string;
  category: string;
  riskWeight: number;
}

export interface NLPAnalysis {
  scamIntentConfidence: number; // 0-100
  detectedScamPhrases: string[];
  scamCategory?: string;
  scriptFingerprintHash: string;
  urgencyLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  manipulationTactics: string[];
}

// ==================== DEVICE FORENSICS ====================
export interface DeviceRiskAnalysis {
  deviceRiskScore: number; // 0-100
  riskFlags: string[];
  isNewDevice: boolean;
  fingerprintMismatch: boolean;
  locationMismatch: boolean;
  vpnDetected: boolean;
  emulatorDetected: boolean;
  suspiciousPatterns: string[];
}

// ==================== TRANSACTION GRAPH ====================
export interface GraphNode {
  id: string;
  type: 'USER' | 'UPI' | 'PHONE';
  trustScore: number;
  flaggedCount: number;
  totalTransactions: number;
  linkedSuspiciousCount: number;
}

export interface GraphEdge {
  from: string;
  to: string;
  transactionCount: number;
  totalAmount: number;
  lastTransaction: string;
  isSuspicious: boolean;
}

export interface GraphAnalysis {
  graphRiskScore: number; // 0-100
  linkedSuspiciousCount: number;
  isMuleAccount: boolean;
  fraudClusterDetected: boolean;
  clusterInfo?: {
    clusterId: string;
    size: number;
    totalFraudAmount: number;
  };
  receiverTrustScore: number;
}

// ==================== RISK FUSION ENGINE ====================
export interface RiskBreakdown {
  behaviorScore: number;
  voiceScore: number;
  nlpScore: number;
  deviceScore: number;
  graphScore: number;
  amountScore: number;
  contactTrustScore: number;
  locationScore: number;
  timeScore: number;
  featureContributions: {
    feature: string;
    contribution: number;
    explanation: string;
  }[];
}

export interface FusionResult {
  finalFraudProbability: number; // 0-100
  riskCategory: 'GREEN' | 'YELLOW' | 'RED';
  decision: 'ALLOW' | 'WARNING' | 'BLOCK';
  breakdown: RiskBreakdown;
  explainableReasons: string[];
  confidenceLevel: number;
}

// ==================== FORENSICS & COMPLIANCE ====================
export interface FraudExplanation {
  transactionId: string;
  blockReasons: string[];
  featureAnalysis: {
    feature: string;
    value: any;
    contribution: number;
    threshold: number;
    exceeded: boolean;
  }[];
  aiConfidence: number;
  humanReadableExplanation: string;
}

export interface ScamReplay {
  transactionId: string;
  timeline: {
    step: number;
    timestamp: string;
    event: string;
    riskLevel: number;
    aiAction: string;
    details: string;
  }[];
  finalOutcome: string;
  preventedLoss: number;
}

export interface RBIComplianceMapping {
  featureId: string;
  featureName: string;
  rbiGuideline: string;
  guidelineReference: string;
  complianceStatus: 'COMPLIANT' | 'PARTIAL' | 'PENDING';
  implementationDetails: string;
}

// ==================== FRAUDSTER DIGITAL TWIN ====================
export interface FraudsterProfile {
  profileId: string;
  tactics: string[];
  targetDemographics: string[];
  averageAmount: number;
  successRate: number;
  evolutionHistory: {
    date: string;
    tactic: string;
    success: boolean;
  }[];
  currentStrategy: string;
  predictedNextMove: string;
}

// ==================== ADMIN & MONITORING ====================
export interface FraudCluster {
  clusterId: string;
  nodes: string[];
  edges: GraphEdge[];
  totalTransactions: number;
  totalFraudAmount: number;
  detectedAt: string;
  status: 'ACTIVE' | 'MONITORING' | 'NEUTRALIZED';
  riskLevel: 'HIGH' | 'CRITICAL';
}

export interface SystemHealth {
  uptime: number;
  requestsProcessed: number;
  fraudBlocked: number;
  falsePositiveRate: number;
  averageResponseTime: number;
  activeAlerts: number;
}
