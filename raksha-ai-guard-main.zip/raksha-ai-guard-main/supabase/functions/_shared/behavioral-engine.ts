// ============================================================
// RakshaPay AI - Behavioral Biometrics Engine (AMFIS Layer 1)
// Analyzes user interaction patterns to detect coercion/panic
// ============================================================

import type { BehaviorMetrics, BehaviorAnalysis } from './types.ts';

// Thresholds for behavioral anomaly detection
const THRESHOLDS = {
  clickSpeed: { normal: 2, suspicious: 5, panic: 8 }, // clicks/second
  hesitationTime: { normal: 2000, suspicious: 500, rushed: 100 }, // ms
  rapidRetries: { normal: 1, suspicious: 3, panic: 5 },
  backAndForth: { normal: 2, suspicious: 5, panic: 8 },
  panicConfirmations: { normal: 0, suspicious: 2, critical: 4 },
  typingSpeed: { slow: 100, normal: 250, fast: 400, suspicious: 600 },
  sessionDuration: { tooShort: 10, normal: 30, suspicious: 5 } // seconds
};

// Night hours (IST) - 11 PM to 6 AM
const NIGHT_START_HOUR = 23;
const NIGHT_END_HOUR = 6;

/**
 * Analyzes behavioral biometrics to detect anomalies and coercion
 * Returns a risk score and cognitive load indicator
 */
export function analyzeBehavior(metrics: BehaviorMetrics): BehaviorAnalysis {
  console.log('[BEHAVIOR_ENGINE] Analyzing behavioral metrics:', JSON.stringify(metrics));
  
  const anomalies: string[] = [];
  let riskScore = 0;
  
  // 1. Click Speed Analysis
  if (metrics.clickSpeed > THRESHOLDS.clickSpeed.panic) {
    anomalies.push('PANIC_CLICKING: Extremely rapid clicking detected');
    riskScore += 25;
  } else if (metrics.clickSpeed > THRESHOLDS.clickSpeed.suspicious) {
    anomalies.push('RAPID_CLICKING: Faster than normal click rate');
    riskScore += 15;
  }
  
  // 2. Hesitation Time Analysis
  if (metrics.hesitationTime < THRESHOLDS.hesitationTime.rushed) {
    anomalies.push('NO_HESITATION: User rushing without reading');
    riskScore += 20;
  } else if (metrics.hesitationTime < THRESHOLDS.hesitationTime.suspicious) {
    anomalies.push('LOW_HESITATION: Minimal pause before action');
    riskScore += 10;
  }
  
  // 3. Rapid Retry Analysis
  if (metrics.rapidRetries >= THRESHOLDS.rapidRetries.panic) {
    anomalies.push('EXCESSIVE_RETRIES: Multiple failed/retry attempts');
    riskScore += 25;
  } else if (metrics.rapidRetries >= THRESHOLDS.rapidRetries.suspicious) {
    anomalies.push('MULTIPLE_RETRIES: Unusual retry pattern');
    riskScore += 12;
  }
  
  // 4. Navigation Pattern Analysis
  if (metrics.backAndForthNavigation >= THRESHOLDS.backAndForth.panic) {
    anomalies.push('ERRATIC_NAVIGATION: Confusion/coercion pattern');
    riskScore += 20;
  } else if (metrics.backAndForthNavigation >= THRESHOLDS.backAndForth.suspicious) {
    anomalies.push('UNUSUAL_NAVIGATION: Back-and-forth behavior');
    riskScore += 10;
  }
  
  // 5. Panic Confirmation Detection
  if (metrics.panicConfirmations >= THRESHOLDS.panicConfirmations.critical) {
    anomalies.push('PANIC_CONFIRMATIONS: Rapid multiple confirmations');
    riskScore += 30;
  } else if (metrics.panicConfirmations >= THRESHOLDS.panicConfirmations.suspicious) {
    anomalies.push('RUSHED_CONFIRMATIONS: Quick successive confirmations');
    riskScore += 15;
  }
  
  // 6. Night-time Transaction Risk
  if (metrics.isNightTime) {
    anomalies.push('NIGHT_TRANSACTION: Late-night activity (higher risk)');
    riskScore += 15;
  }
  
  // 7. Session Duration Analysis
  if (metrics.sessionDuration < THRESHOLDS.sessionDuration.suspicious) {
    anomalies.push('RUSHED_SESSION: Unusually short session');
    riskScore += 20;
  } else if (metrics.sessionDuration < THRESHOLDS.sessionDuration.tooShort) {
    anomalies.push('INSTANT_SESSION: Suspiciously quick transaction attempt');
    riskScore += 30;
  }
  
  // 8. Typing Speed Analysis (if available)
  if (metrics.typingSpeed > THRESHOLDS.typingSpeed.suspicious) {
    anomalies.push('ABNORMAL_TYPING: Typing speed suggests copy-paste or automation');
    riskScore += 15;
  }
  
  // 9. Touch Pressure Analysis (if available)
  if (metrics.touchPressure !== undefined) {
    if (metrics.touchPressure > 0.85) {
      anomalies.push('HIGH_PRESSURE: Stressed/forceful touch pattern');
      riskScore += 10;
    }
  }
  
  // Cap risk score at 100
  riskScore = Math.min(riskScore, 100);
  
  // Determine cognitive load indicator
  const cognitiveLoad = determineCognitiveLoad(riskScore, anomalies);
  
  // Determine overall status
  const status = riskScore > 40 ? 'ANOMALOUS' : 'NORMAL';
  
  // Calculate confidence based on number of data points
  const dataPointsAvailable = Object.values(metrics).filter(v => v !== undefined && v !== null).length;
  const confidence = Math.min(95, 50 + (dataPointsAvailable * 5));
  
  const result: BehaviorAnalysis = {
    riskScore,
    status,
    cognitiveLoadIndicator: cognitiveLoad,
    anomalies,
    confidence
  };
  
  console.log('[BEHAVIOR_ENGINE] Analysis result:', JSON.stringify(result));
  return result;
}

/**
 * Determines cognitive load based on behavior patterns
 */
function determineCognitiveLoad(
  riskScore: number, 
  anomalies: string[]
): 'CALM' | 'PRESSURED' | 'PANIC' {
  // Check for panic indicators
  const panicIndicators = anomalies.filter(a => 
    a.includes('PANIC') || 
    a.includes('EXCESSIVE') || 
    a.includes('ERRATIC')
  );
  
  if (panicIndicators.length >= 2 || riskScore >= 70) {
    return 'PANIC';
  }
  
  if (riskScore >= 35 || anomalies.length >= 3) {
    return 'PRESSURED';
  }
  
  return 'CALM';
}

/**
 * Checks if current time is during high-risk night hours
 */
export function isNightTimeIST(): boolean {
  const now = new Date();
  // Convert to IST (UTC+5:30)
  const istOffset = 5.5 * 60;
  const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
  const istMinutes = utcMinutes + istOffset;
  const istHour = Math.floor((istMinutes / 60) % 24);
  
  return istHour >= NIGHT_START_HOUR || istHour < NIGHT_END_HOUR;
}

/**
 * Generates mock behavioral metrics for testing
 */
export function generateMockBehaviorMetrics(scenario: 'normal' | 'suspicious' | 'panic'): BehaviorMetrics {
  switch (scenario) {
    case 'panic':
      return {
        clickSpeed: 9,
        hesitationTime: 50,
        rapidRetries: 6,
        backAndForthNavigation: 10,
        panicConfirmations: 5,
        isNightTime: true,
        sessionDuration: 3,
        typingSpeed: 700,
        touchPressure: 0.92
      };
    case 'suspicious':
      return {
        clickSpeed: 5.5,
        hesitationTime: 300,
        rapidRetries: 3,
        backAndForthNavigation: 6,
        panicConfirmations: 2,
        isNightTime: false,
        sessionDuration: 15,
        typingSpeed: 450,
        touchPressure: 0.7
      };
    default:
      return {
        clickSpeed: 1.5,
        hesitationTime: 3000,
        rapidRetries: 0,
        backAndForthNavigation: 1,
        panicConfirmations: 0,
        isNightTime: false,
        sessionDuration: 45,
        typingSpeed: 200,
        touchPressure: 0.5
      };
  }
}
