// ============================================================
// RakshaPay AI - NLP Scam Intent Detection (AMFIS Layer 3)
// Analyzes messages/SMS for scam indicators and patterns
// ============================================================

import type { NLPAnalysis, ScamKeyword } from './types.ts';
import { scamKeywords, scamScriptHashes, hashScamScript } from './mock-database.ts';

// Manipulation tactics patterns
const MANIPULATION_PATTERNS = {
  urgency: ['immediately', 'urgent', 'now', 'today only', 'expires', 'last chance', 'hurry'],
  authority: ['rbi', 'police', 'government', 'court', 'official', 'department', 'ministry'],
  fear: ['blocked', 'suspended', 'arrested', 'legal action', 'case filed', 'warrant'],
  greed: ['won', 'prize', 'lottery', 'cashback', 'reward', 'bonus', 'free'],
  trust: ['verified', 'official', 'authentic', 'genuine', 'trusted', 'secure']
};

// Urgency level thresholds
const URGENCY_THRESHOLDS = {
  low: 20,
  medium: 40,
  high: 60,
  critical: 80
};

/**
 * Analyzes text content for scam indicators
 */
export function analyzeScamIntent(messages: string[]): NLPAnalysis {
  console.log('[NLP_ENGINE] Analyzing messages for scam intent:', messages.length, 'messages');
  
  if (!messages || messages.length === 0) {
    return {
      scamIntentConfidence: 0,
      detectedScamPhrases: [],
      urgencyLevel: 'LOW',
      manipulationTactics: [],
      scriptFingerprintHash: ''
    };
  }
  
  // Combine all messages for analysis
  const combinedText = messages.join(' ').toLowerCase();
  
  // Detect scam keywords
  const detectedPhrases = detectScamKeywords(combinedText);
  
  // Detect manipulation tactics
  const tactics = detectManipulationTactics(combinedText);
  
  // Calculate scam intent confidence
  const confidence = calculateScamConfidence(detectedPhrases, tactics);
  
  // Determine scam category
  const category = determineScamCategory(detectedPhrases);
  
  // Generate script fingerprint
  const fingerprint = hashScamScript(combinedText);
  
  // Check if this is a known scam script
  const knownScript = scamScriptHashes.get(fingerprint);
  if (knownScript) {
    console.log('[NLP_ENGINE] Known scam script detected:', fingerprint);
  }
  
  // Determine urgency level
  const urgencyLevel = determineUrgencyLevel(confidence, tactics);
  
  const result: NLPAnalysis = {
    scamIntentConfidence: confidence,
    detectedScamPhrases: detectedPhrases.map(p => p.phrase),
    scamCategory: category,
    scriptFingerprintHash: fingerprint,
    urgencyLevel,
    manipulationTactics: tactics
  };
  
  console.log('[NLP_ENGINE] Analysis result:', JSON.stringify(result));
  return result;
}

/**
 * Detects known scam keywords in text
 */
function detectScamKeywords(text: string): ScamKeyword[] {
  const detected: ScamKeyword[] = [];
  
  for (const keyword of scamKeywords) {
    if (text.includes(keyword.phrase.toLowerCase())) {
      detected.push(keyword);
    }
  }
  
  // Sort by risk weight (highest first)
  return detected.sort((a, b) => b.riskWeight - a.riskWeight);
}

/**
 * Detects manipulation tactics used in the message
 */
function detectManipulationTactics(text: string): string[] {
  const tactics: string[] = [];
  
  for (const [tactic, patterns] of Object.entries(MANIPULATION_PATTERNS)) {
    const matchCount = patterns.filter(p => text.includes(p)).length;
    if (matchCount > 0) {
      const intensity = matchCount >= 3 ? 'heavy' : matchCount >= 2 ? 'moderate' : 'light';
      tactics.push(`${tactic.toUpperCase()}_MANIPULATION (${intensity})`);
    }
  }
  
  return tactics;
}

/**
 * Calculates overall scam confidence score
 */
function calculateScamConfidence(
  detectedPhrases: ScamKeyword[], 
  tactics: string[]
): number {
  if (detectedPhrases.length === 0 && tactics.length === 0) {
    return 0;
  }
  
  // Base score from detected phrases
  let confidence = 0;
  
  // Weight from scam keywords (max 70 from keywords)
  const keywordScore = detectedPhrases.reduce((sum, kw) => sum + kw.riskWeight, 0);
  confidence += Math.min(70, keywordScore / detectedPhrases.length || 0);
  
  // Additional weight from manipulation tactics (max 30 from tactics)
  confidence += Math.min(30, tactics.length * 10);
  
  // Boost for multiple categories of scam indicators
  const categories = new Set(detectedPhrases.map(p => p.category));
  if (categories.size >= 2) {
    confidence += 10;
  }
  if (categories.size >= 3) {
    confidence += 10;
  }
  
  // Heavy manipulation boosts confidence
  const heavyManipulation = tactics.filter(t => t.includes('heavy')).length;
  confidence += heavyManipulation * 5;
  
  return Math.min(100, Math.round(confidence));
}

/**
 * Determines the primary scam category
 */
function determineScamCategory(detectedPhrases: ScamKeyword[]): string | undefined {
  if (detectedPhrases.length === 0) return undefined;
  
  // Count categories
  const categoryCounts = new Map<string, number>();
  for (const phrase of detectedPhrases) {
    categoryCounts.set(phrase.category, (categoryCounts.get(phrase.category) || 0) + 1);
  }
  
  // Find most common category
  let maxCategory = '';
  let maxCount = 0;
  for (const [category, count] of categoryCounts) {
    if (count > maxCount) {
      maxCount = count;
      maxCategory = category;
    }
  }
  
  return maxCategory || undefined;
}

/**
 * Determines urgency level based on confidence and tactics
 */
function determineUrgencyLevel(
  confidence: number, 
  tactics: string[]
): NLPAnalysis['urgencyLevel'] {
  // Check for explicit urgency tactics
  const hasUrgencyTactic = tactics.some(t => t.includes('URGENCY'));
  const hasFearTactic = tactics.some(t => t.includes('FEAR'));
  
  if (confidence >= URGENCY_THRESHOLDS.critical || (hasUrgencyTactic && hasFearTactic)) {
    return 'CRITICAL';
  }
  if (confidence >= URGENCY_THRESHOLDS.high || hasUrgencyTactic) {
    return 'HIGH';
  }
  if (confidence >= URGENCY_THRESHOLDS.medium) {
    return 'MEDIUM';
  }
  return 'LOW';
}

/**
 * Generates mock messages for testing
 */
export function generateMockMessages(scenario: 'clean' | 'suspicious' | 'scam'): string[] {
  switch (scenario) {
    case 'scam':
      return [
        'URGENT: Your refund of Rs.15000 is pending! Click link to claim NOW or it expires today.',
        'RBI WARNING: Your KYC is not updated. Your account will be blocked. Call immediately.',
        'You have WON Rs.50 Lakhs in lottery! Pay Rs.2000 processing fee to claim prize money.'
      ];
    case 'suspicious':
      return [
        'Your parcel is stuck at customs. Pay Rs.500 to release.',
        'Dear customer, verify your identity to continue using services.'
      ];
    default:
      return [
        'Your Amazon order has been delivered.',
        'Thank you for your payment to Flipkart.'
      ];
  }
}

/**
 * Gets NLP risk score for fusion engine
 */
export function getNLPRiskScore(analysis: NLPAnalysis): number {
  return analysis.scamIntentConfidence;
}
