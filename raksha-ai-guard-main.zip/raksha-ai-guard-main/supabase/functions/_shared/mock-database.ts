// ============================================================
// RakshaPay AI - Mock Database (In-Memory Data Store)
// Simulates persistent storage for demo purposes
// ============================================================

import type {
  User,
  GraphNode,
  GraphEdge,
  FraudCluster,
  ScamKeyword,
  FraudsterProfile,
  TransactionResult
} from './types.ts';

// ==================== USERS DATABASE ====================
export const usersDB: Map<string, User> = new Map([
  ['user_001', {
    userId: 'user_001',
    phone: '+919876543210',
    email: 'rahul.sharma@email.com',
    name: 'Rahul Sharma',
    passwordHash: 'hashed_secure123',
    passwordSetAt: '2024-01-15T10:30:00Z',
    isPasswordSet: true,
    createdAt: '2023-06-01T00:00:00Z',
    lastLogin: '2024-12-24T08:00:00Z',
    trustScore: 85,
    isBlocked: false
  }],
  ['user_002', {
    userId: 'user_002',
    phone: '+919123456789',
    email: 'priya.patel@email.com',
    name: 'Priya Patel',
    passwordHash: 'hashed_mypass456',
    passwordSetAt: '2024-02-20T14:15:00Z',
    isPasswordSet: true,
    createdAt: '2023-09-15T00:00:00Z',
    lastLogin: '2024-12-23T16:30:00Z',
    trustScore: 92,
    isBlocked: false
  }],
  ['user_003', {
    userId: 'user_003',
    phone: '+919555555555',
    email: 'victim.user@email.com',
    name: 'Amit Kumar',
    passwordHash: '',
    passwordSetAt: '',
    isPasswordSet: false,
    createdAt: '2024-10-01T00:00:00Z',
    lastLogin: '2024-12-24T02:00:00Z',
    trustScore: 45,
    isBlocked: false
  }]
]);

// ==================== KNOWN FRAUDSTERS & BLOCKED UPIs ====================
export const blockedUPIs: Set<string> = new Set([
  'fraud@upi',
  'scammer123@bank',
  'fake.refund@upi',
  'kyc.update@fraud',
  'lottery.winner@scam'
]);

export const blockedPhones: Set<string> = new Set([
  '+919999999999',
  '+918888888888',
  '+917777777777'
]);

// ==================== TRANSACTION GRAPH DATABASE ====================
export const graphNodes: Map<string, GraphNode> = new Map([
  ['user_001', {
    id: 'user_001',
    type: 'USER',
    trustScore: 85,
    flaggedCount: 0,
    totalTransactions: 156,
    linkedSuspiciousCount: 0
  }],
  ['user_002', {
    id: 'user_002',
    type: 'USER',
    trustScore: 92,
    flaggedCount: 0,
    totalTransactions: 89,
    linkedSuspiciousCount: 0
  }],
  ['merchant@paytm', {
    id: 'merchant@paytm',
    type: 'UPI',
    trustScore: 95,
    flaggedCount: 0,
    totalTransactions: 50000,
    linkedSuspiciousCount: 2
  }],
  ['fraud@upi', {
    id: 'fraud@upi',
    type: 'UPI',
    trustScore: 5,
    flaggedCount: 847,
    totalTransactions: 1250,
    linkedSuspiciousCount: 423
  }],
  ['mule_account_1@upi', {
    id: 'mule_account_1@upi',
    type: 'UPI',
    trustScore: 12,
    flaggedCount: 156,
    totalTransactions: 890,
    linkedSuspiciousCount: 78
  }]
]);

export const graphEdges: GraphEdge[] = [
  {
    from: 'fraud@upi',
    to: 'mule_account_1@upi',
    transactionCount: 234,
    totalAmount: 4567890,
    lastTransaction: '2024-12-23T23:45:00Z',
    isSuspicious: true
  },
  {
    from: 'user_001',
    to: 'merchant@paytm',
    transactionCount: 45,
    totalAmount: 125000,
    lastTransaction: '2024-12-24T07:30:00Z',
    isSuspicious: false
  }
];

// ==================== FRAUD CLUSTERS ====================
export const fraudClusters: FraudCluster[] = [
  {
    clusterId: 'cluster_001',
    nodes: ['fraud@upi', 'mule_account_1@upi', 'scammer123@bank'],
    edges: graphEdges.filter(e => e.isSuspicious),
    totalTransactions: 2340,
    totalFraudAmount: 12500000,
    detectedAt: '2024-12-20T14:30:00Z',
    status: 'ACTIVE',
    riskLevel: 'CRITICAL'
  },
  {
    clusterId: 'cluster_002',
    nodes: ['fake.refund@upi', 'kyc.update@fraud'],
    edges: [],
    totalTransactions: 567,
    totalFraudAmount: 3400000,
    detectedAt: '2024-12-22T09:15:00Z',
    status: 'MONITORING',
    riskLevel: 'HIGH'
  }
];

// ==================== SCAM KEYWORDS DATABASE ====================
export const scamKeywords: ScamKeyword[] = [
  // Refund Scams
  { phrase: 'refund pending', category: 'REFUND_SCAM', riskWeight: 85 },
  { phrase: 'cashback credited', category: 'REFUND_SCAM', riskWeight: 80 },
  { phrase: 'refund failed', category: 'REFUND_SCAM', riskWeight: 90 },
  { phrase: 'claim your refund', category: 'REFUND_SCAM', riskWeight: 95 },
  
  // KYC Scams
  { phrase: 'kyc update required', category: 'KYC_SCAM', riskWeight: 92 },
  { phrase: 'account will be blocked', category: 'KYC_SCAM', riskWeight: 88 },
  { phrase: 'verify your identity', category: 'KYC_SCAM', riskWeight: 75 },
  { phrase: 'pan card link mandatory', category: 'KYC_SCAM', riskWeight: 85 },
  
  // Parcel/Courier Scams
  { phrase: 'parcel stuck customs', category: 'PARCEL_SCAM', riskWeight: 87 },
  { phrase: 'delivery failed pay', category: 'PARCEL_SCAM', riskWeight: 90 },
  { phrase: 'courier detained', category: 'PARCEL_SCAM', riskWeight: 85 },
  
  // Urgency Triggers
  { phrase: 'urgent payment', category: 'URGENCY', riskWeight: 78 },
  { phrase: 'immediate action required', category: 'URGENCY', riskWeight: 82 },
  { phrase: 'expires in 24 hours', category: 'URGENCY', riskWeight: 75 },
  { phrase: 'act now', category: 'URGENCY', riskWeight: 70 },
  
  // Authority Impersonation
  { phrase: 'rbi warning', category: 'AUTHORITY_SCAM', riskWeight: 95 },
  { phrase: 'police case registered', category: 'AUTHORITY_SCAM', riskWeight: 98 },
  { phrase: 'income tax department', category: 'AUTHORITY_SCAM', riskWeight: 90 },
  { phrase: 'court summons', category: 'AUTHORITY_SCAM', riskWeight: 95 },
  
  // Lottery/Prize Scams
  { phrase: 'lottery winner', category: 'LOTTERY_SCAM', riskWeight: 99 },
  { phrase: 'prize money', category: 'LOTTERY_SCAM', riskWeight: 90 },
  { phrase: 'you have won', category: 'LOTTERY_SCAM', riskWeight: 85 },
  
  // Investment Scams
  { phrase: 'guaranteed returns', category: 'INVESTMENT_SCAM', riskWeight: 92 },
  { phrase: 'double your money', category: 'INVESTMENT_SCAM', riskWeight: 98 },
  { phrase: 'risk free investment', category: 'INVESTMENT_SCAM', riskWeight: 95 }
];

// ==================== SCAM SCRIPT FINGERPRINTS ====================
export const scamScriptHashes: Map<string, { count: number; lastSeen: string; category: string }> = new Map([
  ['abc123hash', { count: 456, lastSeen: '2024-12-24T01:00:00Z', category: 'REFUND_SCAM' }],
  ['def456hash', { count: 234, lastSeen: '2024-12-23T18:30:00Z', category: 'KYC_SCAM' }],
  ['ghi789hash', { count: 789, lastSeen: '2024-12-24T06:15:00Z', category: 'PARCEL_SCAM' }]
]);

// ==================== FRAUDSTER DIGITAL TWINS ====================
export const fraudsterProfiles: FraudsterProfile[] = [
  {
    profileId: 'fraudster_001',
    tactics: ['Refund Scam', 'Social Engineering', 'Urgency Creation'],
    targetDemographics: ['Senior Citizens', 'First-time UPI users'],
    averageAmount: 15000,
    successRate: 0.12,
    evolutionHistory: [
      { date: '2024-10-01', tactic: 'Simple refund SMS', success: true },
      { date: '2024-11-15', tactic: 'Added voice call component', success: true },
      { date: '2024-12-01', tactic: 'Using AI-generated voice', success: false }
    ],
    currentStrategy: 'Combining deepfake voice with urgent refund narrative',
    predictedNextMove: 'Will likely add video component or target younger demographics'
  },
  {
    profileId: 'fraudster_002',
    tactics: ['KYC Scam', 'Authority Impersonation', 'Fear Tactics'],
    targetDemographics: ['Middle-aged professionals', 'Small business owners'],
    averageAmount: 45000,
    successRate: 0.08,
    evolutionHistory: [
      { date: '2024-09-01', tactic: 'RBI impersonation SMS', success: true },
      { date: '2024-10-20', tactic: 'Added fake official website', success: true },
      { date: '2024-12-10', tactic: 'Screen sharing attack', success: false }
    ],
    currentStrategy: 'Remote desktop access combined with official-looking communications',
    predictedNextMove: 'Expected to create fake mobile apps mimicking bank apps'
  }
];

// ==================== KNOWN DEVICE FINGERPRINTS ====================
export const trustedDevices: Map<string, string[]> = new Map([
  ['user_001', ['device_fp_abc123', 'device_fp_def456']],
  ['user_002', ['device_fp_ghi789']]
]);

// ==================== TRANSACTION HISTORY ====================
export const transactionHistory: TransactionResult[] = [];

// ==================== RBI COMPLIANCE MAPPINGS ====================
export const rbiComplianceMappings = [
  {
    featureId: 'AMT_LIMIT_CHECK',
    featureName: 'Amount Limit Verification',
    rbiGuideline: 'Transaction amount limits as per RBI circular',
    guidelineReference: 'RBI/2023-24/XX/DPS/XXX',
    complianceStatus: 'COMPLIANT' as const,
    implementationDetails: 'Real-time amount limit checks for ₹500+, ₹2000+, ₹20000+ thresholds'
  },
  {
    featureId: 'COOLING_PERIOD',
    featureName: 'Cooling-off Period for High-Risk Transactions',
    rbiGuideline: 'Mandatory delay for suspicious high-value transactions',
    guidelineReference: 'RBI/2023-24/XX/DPS/XXX',
    complianceStatus: 'COMPLIANT' as const,
    implementationDetails: 'Automatic cooling-off timer for blocked transactions'
  },
  {
    featureId: 'RECEIVER_VERIFICATION',
    featureName: 'Beneficiary Verification',
    rbiGuideline: 'Verification of receiver details before transaction',
    guidelineReference: 'RBI/2022-23/XX/DPS/XXX',
    complianceStatus: 'COMPLIANT' as const,
    implementationDetails: 'Graph-based receiver trust scoring and verification'
  },
  {
    featureId: 'FRAUD_ALERT',
    featureName: 'Real-time Fraud Alerts',
    rbiGuideline: 'Immediate notification to customers for suspicious activities',
    guidelineReference: 'RBI/2023-24/XX/DPS/XXX',
    complianceStatus: 'COMPLIANT' as const,
    implementationDetails: 'AI-powered real-time fraud detection and alerting'
  },
  {
    featureId: 'BIOMETRIC_AUTH',
    featureName: 'Multi-factor Authentication',
    rbiGuideline: 'Additional authentication for high-value transactions',
    guidelineReference: 'RBI/2021-22/XX/DPS/XXX',
    complianceStatus: 'COMPLIANT' as const,
    implementationDetails: 'Security password + behavioral biometrics verification'
  },
  {
    featureId: 'DEVICE_BINDING',
    featureName: 'Device Binding & Fingerprinting',
    rbiGuideline: 'Secure device registration for UPI transactions',
    guidelineReference: 'RBI/2022-23/XX/DPS/XXX',
    complianceStatus: 'COMPLIANT' as const,
    implementationDetails: 'Device fingerprint tracking with anomaly detection'
  }
];

// ==================== HELPER FUNCTIONS ====================
export function generateTransactionId(): string {
  return `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
}

export function hashScamScript(text: string): string {
  // Simple hash simulation for demo
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16);
}

export function getReceiverTrustScore(receiverUpi: string): number {
  const node = graphNodes.get(receiverUpi);
  if (node) return node.trustScore;
  
  // Unknown receiver - check if it's blocked
  if (blockedUPIs.has(receiverUpi)) return 0;
  
  // New/unknown receiver gets neutral score
  return 50;
}

export function isBlockedReceiver(receiverUpi: string, receiverPhone?: string): boolean {
  if (blockedUPIs.has(receiverUpi)) return true;
  if (receiverPhone && blockedPhones.has(receiverPhone)) return true;
  return false;
}
