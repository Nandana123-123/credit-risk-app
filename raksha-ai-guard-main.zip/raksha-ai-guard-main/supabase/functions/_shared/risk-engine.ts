// ============================================================
// RakshaPay AI - Device Forensics & Risk Fusion Engine
// AMFIS Layers 4-6: Device analysis, Graph, and Core Brain
// ============================================================

import type { DeviceInfo, LocationInfo, DeviceRiskAnalysis, GraphAnalysis, FusionResult, RiskBreakdown, TransactionRequest } from './types.ts';
import { graphNodes, trustedDevices, blockedUPIs } from './mock-database.ts';
import { analyzeBehavior } from './behavioral-engine.ts';
import { analyzeVoice, getVoiceRiskScore } from './voice-detection.ts';
import { analyzeScamIntent, getNLPRiskScore } from './nlp-detection.ts';

// ==================== DEVICE FORENSICS (Layer 4) ====================
export function analyzeDevice(userId: string, device: DeviceInfo, location: LocationInfo): DeviceRiskAnalysis {
  console.log('[DEVICE_ENGINE] Analyzing device:', device.deviceId);
  const riskFlags: string[] = [];
  let riskScore = 0;

  // Check if new device
  const userDevices = trustedDevices.get(userId) || [];
  const isNewDevice = !userDevices.includes(device.fingerprint);
  if (isNewDevice) { riskFlags.push('NEW_DEVICE'); riskScore += 20; }

  // Emulator detection
  if (device.isEmulator) { riskFlags.push('EMULATOR_DETECTED'); riskScore += 35; }
  if (device.isRooted) { riskFlags.push('ROOTED_DEVICE'); riskScore += 25; }

  // VPN/Proxy detection
  if (location.isVPN) { riskFlags.push('VPN_DETECTED'); riskScore += 20; }
  if (location.isProxy) { riskFlags.push('PROXY_DETECTED'); riskScore += 25; }

  // Location mismatch (simplified check)
  const locationMismatch = location.country !== 'India';
  if (locationMismatch) { riskFlags.push('LOCATION_MISMATCH'); riskScore += 30; }

  return {
    deviceRiskScore: Math.min(100, riskScore),
    riskFlags,
    isNewDevice,
    fingerprintMismatch: isNewDevice,
    locationMismatch,
    vpnDetected: location.isVPN,
    emulatorDetected: device.isEmulator,
    suspiciousPatterns: riskFlags
  };
}

// ==================== GRAPH INTELLIGENCE (Layer 5) ====================
export function analyzeGraph(receiverUpi: string): GraphAnalysis {
  console.log('[GRAPH_ENGINE] Analyzing receiver:', receiverUpi);
  const node = graphNodes.get(receiverUpi);
  
  if (!node) {
    return {
      graphRiskScore: blockedUPIs.has(receiverUpi) ? 100 : 40,
      linkedSuspiciousCount: 0,
      isMuleAccount: blockedUPIs.has(receiverUpi),
      fraudClusterDetected: false,
      receiverTrustScore: blockedUPIs.has(receiverUpi) ? 0 : 50
    };
  }

  const isMule = node.flaggedCount > 50 || node.trustScore < 20;
  return {
    graphRiskScore: Math.max(0, 100 - node.trustScore),
    linkedSuspiciousCount: node.linkedSuspiciousCount,
    isMuleAccount: isMule,
    fraudClusterDetected: node.linkedSuspiciousCount > 10,
    receiverTrustScore: node.trustScore,
    clusterInfo: node.linkedSuspiciousCount > 10 ? { clusterId: 'cluster_001', size: node.linkedSuspiciousCount, totalFraudAmount: 1250000 } : undefined
  };
}

// ==================== RISK FUSION ENGINE (Layer 6 - CORE BRAIN) ====================
export function fuseRiskScores(request: TransactionRequest): FusionResult {
  console.log('[FUSION_ENGINE] Processing transaction:', request.transactionId);

  // Run all analysis engines
  const behaviorResult = analyzeBehavior(request.behaviorMetrics);
  const voiceResult = analyzeVoice(request.voiceSample, request.callActive);
  const nlpResult = analyzeScamIntent(request.recentMessages || []);
  const deviceResult = analyzeDevice(request.senderId, request.deviceInfo, request.locationInfo);
  const graphResult = analyzeGraph(request.receiverUpiId);

  // Calculate component scores
  const scores = {
    behavior: behaviorResult.riskScore,
    voice: getVoiceRiskScore(voiceResult),
    nlp: getNLPRiskScore(nlpResult),
    device: deviceResult.deviceRiskScore,
    graph: graphResult.graphRiskScore,
    amount: calculateAmountRisk(request.amount),
    contactTrust: 100 - graphResult.receiverTrustScore,
    location: deviceResult.locationMismatch ? 40 : 0,
    time: request.behaviorMetrics.isNightTime ? 20 : 0
  };

  // Weighted fusion (weights sum to 1.0)
  const weights = { behavior: 0.15, voice: 0.12, nlp: 0.18, device: 0.12, graph: 0.20, amount: 0.10, contactTrust: 0.08, location: 0.03, time: 0.02 };
  
  let finalScore = Object.entries(scores).reduce((sum, [key, score]) => 
    sum + score * (weights[key as keyof typeof weights] || 0), 0);

  // Critical overrides
  if (blockedUPIs.has(request.receiverUpiId)) finalScore = 100;
  if (voiceResult.classification === 'DEEPFAKE') finalScore = Math.max(finalScore, 90);
  if (nlpResult.urgencyLevel === 'CRITICAL') finalScore = Math.max(finalScore, 85);

  finalScore = Math.min(100, Math.round(finalScore));

  // Determine decision
  const riskCategory = finalScore >= 70 ? 'RED' : finalScore >= 40 ? 'YELLOW' : 'GREEN';
  const decision = finalScore >= 70 ? 'BLOCK' : finalScore >= 40 ? 'WARNING' : 'ALLOW';

  // Build explainable breakdown
  const breakdown: RiskBreakdown = {
    behaviorScore: scores.behavior,
    voiceScore: scores.voice,
    nlpScore: scores.nlp,
    deviceScore: scores.device,
    graphScore: scores.graph,
    amountScore: scores.amount,
    contactTrustScore: scores.contactTrust,
    locationScore: scores.location,
    timeScore: scores.time,
    featureContributions: Object.entries(scores)
      .filter(([_, v]) => v > 0)
      .map(([k, v]) => ({ feature: k.toUpperCase(), contribution: Math.round(v * (weights[k as keyof typeof weights] || 0)), explanation: `${k} risk factor` }))
      .sort((a, b) => b.contribution - a.contribution)
  };

  return { finalFraudProbability: finalScore, riskCategory, decision, breakdown, explainableReasons: generateReasons(scores, request), confidenceLevel: 87 };
}

function calculateAmountRisk(amount: number): number {
  if (amount >= 20000) return 60;
  if (amount >= 2000) return 35;
  if (amount >= 500) return 15;
  return 0;
}

function generateReasons(scores: Record<string, number>, req: TransactionRequest): string[] {
  const reasons: string[] = [];
  if (scores.graph > 50) reasons.push('Receiver has suspicious transaction history');
  if (scores.nlp > 50) reasons.push('Scam patterns detected in recent messages');
  if (scores.behavior > 40) reasons.push('User behavior indicates possible coercion');
  if (scores.voice > 50) reasons.push('Voice analysis detected synthetic/AI patterns');
  if (scores.device > 30) reasons.push('Device/network anomalies detected');
  if (scores.amount > 30) reasons.push(`High-value transaction: ₹${req.amount}`);
  if (blockedUPIs.has(req.receiverUpiId)) reasons.push('Receiver UPI is on fraud watchlist');
  return reasons;
}
