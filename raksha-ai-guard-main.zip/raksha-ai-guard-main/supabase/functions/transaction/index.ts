import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { corsHeaders, jsonResponse, errorResponse, handleCors } from "../_shared/cors.ts";
import { fuseRiskScores } from "../_shared/risk-engine.ts";
import { generateTransactionId, blockedUPIs, blockedPhones, transactionHistory } from "../_shared/mock-database.ts";
import type { TransactionRequest, TransactionResult } from "../_shared/types.ts";

serve(async (req) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  try {
    const body = await req.json();
    const { action, ...data } = body;
    console.log('[TRANSACTION_API] Action:', action);

    switch (action) {
      case 'analyze': {
        const request: TransactionRequest = {
          transactionId: generateTransactionId(),
          senderId: data.senderId || 'user_001',
          senderPhone: data.senderPhone || '+919876543210',
          receiverUpiId: data.receiverUpiId,
          receiverPhone: data.receiverPhone,
          receiverName: data.receiverName,
          amount: data.amount || 0,
          purpose: data.purpose,
          timestamp: new Date().toISOString(),
          deviceInfo: data.deviceInfo || { deviceId: 'dev_001', fingerprint: 'fp_001', platform: 'android', osVersion: '14', appVersion: '2.0', isEmulator: false, isRooted: false, lastSeen: new Date().toISOString() },
          locationInfo: data.locationInfo || { latitude: 19.076, longitude: 72.877, city: 'Mumbai', state: 'Maharashtra', country: 'India', isVPN: false, isProxy: false, ipAddress: '103.x.x.x' },
          behaviorMetrics: data.behaviorMetrics || { clickSpeed: 1.5, hesitationTime: 2000, rapidRetries: 0, backAndForthNavigation: 1, panicConfirmations: 0, isNightTime: false, sessionDuration: 45, typingSpeed: 200 },
          callActive: data.callActive || false,
          voiceSample: data.voiceSample,
          recentMessages: data.recentMessages || []
        };

        const fusionResult = fuseRiskScores(request);
        const blockReasons: string[] = [];
        let coolingOff = 0;

        // Mandatory rules
        if (blockedUPIs.has(request.receiverUpiId)) blockReasons.push('Receiver UPI is blocked');
        if (request.receiverPhone && blockedPhones.has(request.receiverPhone)) blockReasons.push('Receiver phone is blocked');
        if (fusionResult.finalFraudProbability >= 70) blockReasons.push(...fusionResult.explainableReasons);
        if (request.amount >= 20000 && fusionResult.riskCategory !== 'GREEN') { blockReasons.push('Extra verification required for ₹20,000+'); coolingOff = 300; }

        const result: TransactionResult = {
          transactionId: request.transactionId,
          status: fusionResult.decision === 'BLOCK' ? 'BLOCKED' : fusionResult.decision === 'WARNING' ? 'WARNING' : 'ALLOWED',
          finalRiskScore: fusionResult.finalFraudProbability,
          riskCategory: fusionResult.riskCategory,
          blockReasons,
          recommendedAction: fusionResult.decision === 'BLOCK' ? 'Do NOT proceed. Contact your bank.' : fusionResult.decision === 'WARNING' ? 'Verify receiver before proceeding.' : 'Transaction appears safe.',
          analysisBreakdown: fusionResult.breakdown,
          timestamp: new Date().toISOString(),
          coolingOffSeconds: coolingOff || undefined,
          requiresAdditionalVerification: fusionResult.riskCategory !== 'GREEN'
        };

        transactionHistory.push(result);
        return jsonResponse({ success: true, message: 'Transaction Risk Analysis Completed', result });
      }

      case 'execute': {
        const txnId = data.transactionId;
        const lastResult = transactionHistory.find(t => t.transactionId === txnId);
        if (!lastResult) return errorResponse('Transaction not analyzed', 400);
        if (lastResult.status === 'BLOCKED') return errorResponse('Transaction is blocked', 403, { blockReasons: lastResult.blockReasons });
        return jsonResponse({ success: true, message: 'Transaction executed successfully (simulated)', transactionId: txnId, executedAt: new Date().toISOString() });
      }

      default:
        return errorResponse('Invalid action. Use: analyze, execute', 400);
    }
  } catch (error) {
    console.error('[TRANSACTION_API] Error:', error);
    return errorResponse(error instanceof Error ? error.message : 'Unknown error', 500);
  }
});
