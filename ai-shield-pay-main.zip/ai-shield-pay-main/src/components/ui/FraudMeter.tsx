import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface FraudMeterProps {
  probability: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
  className?: string;
}

export function FraudMeter({ 
  probability, 
  showLabel = true, 
  size = 'md',
  animated = true,
  className 
}: FraudMeterProps) {
  const getColor = (prob: number) => {
    if (prob < 30) return { bg: 'bg-safe', glow: 'shadow-success-glow' };
    if (prob < 70) return { bg: 'bg-suspicious', glow: 'shadow-warning-glow' };
    return { bg: 'bg-blocked', glow: 'shadow-danger-glow' };
  };

  const getLabel = (prob: number) => {
    if (prob < 30) return 'Low Risk';
    if (prob < 70) return 'Medium Risk';
    return 'High Risk';
  };

  const { bg, glow } = getColor(probability);
  const heights = { sm: 'h-1.5', md: 'h-2.5', lg: 'h-4' };

  return (
    <div className={cn('w-full', className)}>
      {showLabel && (
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-sm font-medium text-muted-foreground">Fraud Risk</span>
          <span className={cn('text-sm font-bold', {
            'text-safe': probability < 30,
            'text-suspicious': probability >= 30 && probability < 70,
            'text-blocked': probability >= 70,
          })}>
            {probability}% - {getLabel(probability)}
          </span>
        </div>
      )}
      <div className={cn('w-full bg-muted rounded-full overflow-hidden', heights[size])}>
        <motion.div
          className={cn('h-full rounded-full', bg, animated && glow)}
          initial={{ width: 0 }}
          animate={{ width: `${probability}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        />
      </div>
    </div>
  );
}
