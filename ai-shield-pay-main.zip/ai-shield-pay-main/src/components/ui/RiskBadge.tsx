import { motion } from 'framer-motion';
import { Shield, AlertTriangle, XOctagon } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { RiskLevel } from '@/contexts/AppContext';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

const config = {
  safe: {
    icon: Shield,
    label: 'Safe',
    className: 'bg-safe/10 text-safe border-safe/20',
  },
  suspicious: {
    icon: AlertTriangle,
    label: 'Suspicious',
    className: 'bg-suspicious/10 text-suspicious border-suspicious/20',
  },
  blocked: {
    icon: XOctagon,
    label: 'Blocked',
    className: 'bg-blocked/10 text-blocked border-blocked/20',
  },
};

const sizes = {
  sm: 'px-2 py-0.5 text-xs gap-1',
  md: 'px-3 py-1 text-sm gap-1.5',
  lg: 'px-4 py-2 text-base gap-2',
};

const iconSizes = {
  sm: 12,
  md: 14,
  lg: 18,
};

export function RiskBadge({ level, size = 'md', showLabel = true, className }: RiskBadgeProps) {
  const { icon: Icon, label, className: levelClass } = config[level];

  return (
    <motion.span
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={cn(
        'inline-flex items-center rounded-full border font-medium',
        levelClass,
        sizes[size],
        className
      )}
    >
      <Icon size={iconSizes[size]} />
      {showLabel && <span>{label}</span>}
    </motion.span>
  );
}
