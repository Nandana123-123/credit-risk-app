import { motion } from 'framer-motion';
import { Shield, Moon, Sun, Bell, Settings } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export function Header() {
  const { darkMode, setDarkMode } = useApp();

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-50 glass-card border-b border-border/50"
    >
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <motion.div
            whileHover={{ rotate: 10 }}
            className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shadow-glow"
          >
            <Shield className="w-6 h-6 text-primary-foreground" />
          </motion.div>
          <div>
            <h1 className="font-display text-lg font-bold text-foreground leading-tight">
              RakshaPay
            </h1>
            <span className="text-xs text-primary font-medium">AI Protected</span>
          </div>
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-blocked rounded-full" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setDarkMode(!darkMode)}
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>

          <Link to="/admin">
            <Button variant="ghost" size="icon">
              <Settings className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </div>
    </motion.header>
  );
}
