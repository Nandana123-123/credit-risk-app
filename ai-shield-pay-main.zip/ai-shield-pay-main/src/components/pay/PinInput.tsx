import { motion } from 'framer-motion';
import { useState } from 'react';
import { Lock, Delete, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PinInputProps {
  onComplete: (pin: string) => void;
  onCancel: () => void;
  title?: string;
  disabled?: boolean;
}

export function PinInput({ onComplete, onCancel, title = 'Enter UPI PIN', disabled = false }: PinInputProps) {
  const [pin, setPin] = useState('');
  const maxLength = 6;

  const handleNumber = (num: string) => {
    if (pin.length < maxLength && !disabled) {
      const newPin = pin + num;
      setPin(newPin);
      if (newPin.length === maxLength) {
        setTimeout(() => onComplete(newPin), 200);
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };

  const numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'delete'];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-6 space-y-6"
    >
      <div className="text-center space-y-2">
        <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto shadow-glow">
          <Lock className="w-8 h-8 text-primary-foreground" />
        </div>
        <h2 className="font-display text-xl font-bold text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground">Enter your 6-digit UPI PIN to confirm</p>
      </div>

      {/* PIN Display */}
      <div className="flex justify-center gap-3">
        {Array.from({ length: maxLength }).map((_, i) => (
          <motion.div
            key={i}
            animate={{
              scale: i < pin.length ? 1.1 : 1,
              backgroundColor: i < pin.length ? 'hsl(var(--primary))' : 'hsl(var(--muted))',
            }}
            className={cn(
              'w-4 h-4 rounded-full transition-colors',
              i < pin.length ? 'bg-primary' : 'bg-muted'
            )}
          />
        ))}
      </div>

      {/* Keypad */}
      <div className="grid grid-cols-3 gap-3 max-w-xs mx-auto">
        {numbers.map((num, i) => {
          if (num === '') return <div key={i} />;
          if (num === 'delete') {
            return (
              <motion.button
                key={i}
                whileTap={{ scale: 0.95 }}
                onClick={handleDelete}
                disabled={disabled || pin.length === 0}
                className="h-16 rounded-2xl bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors disabled:opacity-50"
              >
                <Delete className="w-6 h-6 text-muted-foreground" />
              </motion.button>
            );
          }
          return (
            <motion.button
              key={i}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleNumber(num)}
              disabled={disabled}
              className="h-16 rounded-2xl bg-card border border-border flex items-center justify-center text-2xl font-display font-semibold text-foreground hover:bg-muted/50 transition-colors disabled:opacity-50"
            >
              {num}
            </motion.button>
          );
        })}
      </div>

      <Button variant="ghost" onClick={onCancel} className="w-full">
        Cancel
      </Button>
    </motion.div>
  );
}
