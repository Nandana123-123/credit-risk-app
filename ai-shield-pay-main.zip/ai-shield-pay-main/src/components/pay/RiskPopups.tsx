import { motion, AnimatePresence } from 'framer-motion';
import { X, AlertTriangle, Shield, Brain, Info, TrendingUp, MapPin, Clock, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FraudMeter } from '@/components/ui/FraudMeter';
import { RiskBadge } from '@/components/ui/RiskBadge';
import type { RiskLevel } from '@/contexts/AppContext';

interface RiskWarning {
  type: 'unusual_amount' | 'high_value' | 'unknown_receiver' | 'repeated_high' | 'location_mismatch' | 'victim_scenario';
  title: string;
  description: string;
  severity: RiskLevel;
}

interface RiskPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: () => void;
  warning: RiskWarning;
  receiverName?: string;
  amount?: number;
}

const warningIcons = {
  unusual_amount: TrendingUp,
  high_value: AlertTriangle,
  unknown_receiver: User,
  repeated_high: Clock,
  location_mismatch: MapPin,
  victim_scenario: Shield,
};

export function RiskPopup({ isOpen, onClose, onContinue, warning, receiverName, amount }: RiskPopupProps) {
  const Icon = warningIcons[warning.type];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-foreground/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-3xl shadow-xl border border-border overflow-hidden"
          >
            {/* Header */}
            <div className={`p-6 ${
              warning.severity === 'blocked' ? 'gradient-danger' :
              warning.severity === 'suspicious' ? 'gradient-warning' :
              'gradient-success'
            }`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-card/20 backdrop-blur flex items-center justify-center">
                    <Icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-bold text-primary-foreground">
                      {warning.title}
                    </h3>
                    <RiskBadge level={warning.severity} size="sm" />
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="w-8 h-8 rounded-lg bg-card/20 flex items-center justify-center hover:bg-card/30 transition-colors"
                >
                  <X className="w-4 h-4 text-primary-foreground" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              <p className="text-foreground">{warning.description}</p>

              {receiverName && (
                <div className="p-4 rounded-xl bg-muted/50 border border-border/50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{receiverName}</p>
                      {amount && (
                        <p className="text-sm text-muted-foreground">
                          Amount: ₹{amount.toLocaleString('en-IN')}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-start gap-2 p-3 rounded-xl bg-warning/5 border border-warning/10">
                <Info className="w-5 h-5 text-warning shrink-0 mt-0.5" />
                <p className="text-sm text-muted-foreground">
                  Our AI has detected potential risk factors. Please verify before proceeding.
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="p-6 pt-0 flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button
                className={`flex-1 ${
                  warning.severity === 'blocked' ? 'gradient-danger' :
                  warning.severity === 'suspicious' ? 'gradient-warning' :
                  'gradient-primary'
                }`}
                onClick={onContinue}
                disabled={warning.severity === 'blocked'}
              >
                {warning.severity === 'blocked' ? 'Transaction Blocked' : 'I Understand, Continue'}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface TransactionAnalysisPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onProceed: () => void;
  fraudProbability: number;
  riskLevel: RiskLevel;
  riskFactors: {
    behaviour: number;
    amountAnomaly: number;
    deviceRisk: number;
    graphRisk: number;
    voiceNlpRisk: number;
  };
}

export function TransactionAnalysisPopup({
  isOpen,
  onClose,
  onProceed,
  fraudProbability,
  riskLevel,
  riskFactors,
}: TransactionAnalysisPopupProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-foreground/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-3xl shadow-xl border border-border overflow-hidden"
          >
            {/* Header */}
            <div className="p-6 border-b border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                  <Brain className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-foreground">
                    Transaction Risk Analysis
                  </h3>
                  <p className="text-sm text-muted-foreground">AI-powered fraud detection</p>
                </div>
              </div>

              <FraudMeter probability={fraudProbability} size="lg" />
            </div>

            {/* Risk Factors */}
            <div className="p-6 space-y-3">
              <h4 className="font-medium text-foreground flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                Risk Factor Breakdown
              </h4>

              {Object.entries(riskFactors).map(([key, value]) => (
                <div key={key} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </span>
                    <span className="font-medium text-foreground">{value}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${value}%` }}
                      transition={{ duration: 0.5, delay: 0.1 }}
                      className={`h-full rounded-full ${
                        value < 20 ? 'bg-safe' : value < 50 ? 'bg-suspicious' : 'bg-blocked'
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Status */}
            <div className="px-6 pb-4">
              <div className={`p-4 rounded-xl flex items-center gap-3 ${
                riskLevel === 'safe' ? 'bg-success/10' :
                riskLevel === 'suspicious' ? 'bg-warning/10' :
                'bg-danger/10'
              }`}>
                <RiskBadge level={riskLevel} size="lg" />
                <div>
                  <p className="font-medium text-foreground">
                    {riskLevel === 'safe' ? 'Transaction Approved' :
                     riskLevel === 'suspicious' ? 'Proceed with Caution' :
                     'Transaction Blocked'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {riskLevel === 'blocked' && 'High fraud probability detected'}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-6 pt-0 flex gap-3">
              <Button variant="outline" className="flex-1" onClick={onClose}>
                Cancel
              </Button>
              <Button
                className="flex-1"
                onClick={onProceed}
                disabled={riskLevel === 'blocked'}
              >
                {riskLevel === 'blocked' ? 'Cannot Proceed' : 'Continue to PIN'}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
