import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, AlertTriangle, Shield, TrendingUp, MapPin, User, Clock, 
  AlertCircle, Skull, Phone, IndianRupee, UserX, Activity 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { RiskLevel } from '@/contexts/AppContext';

export type WarningType = 
  | 'unusual_amount' 
  | 'high_value' 
  | 'very_high_value'
  | 'unknown_receiver' 
  | 'repeated_high' 
  | 'location_mismatch' 
  | 'victim_detected'
  | 'fraud_detected'
  | 'behavioral_anomaly'
  | 'rapid_transactions'
  | 'new_device'
  | 'night_transaction';

interface WarningConfig {
  icon: React.ElementType;
  title: string;
  description: string;
  severity: RiskLevel;
  educationTip?: string;
}

const warningConfigs: Record<WarningType, WarningConfig> = {
  unusual_amount: {
    icon: TrendingUp,
    title: 'Unusual Amount Detected',
    description: 'This amount is higher than your typical transaction pattern. Please verify this is intentional.',
    severity: 'suspicious',
    educationTip: 'Fraudsters often request amounts just below detection thresholds. Always verify the receiver.',
  },
  high_value: {
    icon: IndianRupee,
    title: 'High-Value Transaction Alert',
    description: 'You are about to transfer a large amount. Our AI is performing enhanced security checks.',
    severity: 'suspicious',
    educationTip: 'For amounts above ₹2,000, always double-check the receiver details and verify through a call.',
  },
  very_high_value: {
    icon: AlertTriangle,
    title: '⚠️ Very High Amount Warning',
    description: 'This transaction exceeds ₹20,000. Extra verification is required for your protection.',
    severity: 'suspicious',
    educationTip: 'Large transfers are prime targets for fraud. Consider splitting into smaller amounts.',
  },
  unknown_receiver: {
    icon: UserX,
    title: 'Unknown Receiver',
    description: 'You have never transacted with this person before. Exercise extreme caution.',
    severity: 'suspicious',
    educationTip: 'First-time receivers are a common fraud pattern. Verify identity through multiple channels.',
  },
  repeated_high: {
    icon: Clock,
    title: 'Repeated High-Value Transfers',
    description: 'Multiple large transactions detected in a short period. This matches fraud patterns.',
    severity: 'suspicious',
    educationTip: 'Fraudsters often rush victims into multiple quick transfers. Take your time.',
  },
  location_mismatch: {
    icon: MapPin,
    title: 'Location Mismatch Detected',
    description: 'The receiver\'s location doesn\'t match expected patterns. This is a major fraud indicator.',
    severity: 'suspicious',
    educationTip: 'Scammers often operate from different locations than claimed. Verify physical address.',
  },
  victim_detected: {
    icon: Phone,
    title: '🚨 Potential Victim Scenario',
    description: 'Your transaction pattern matches known victim behaviors. You may be being manipulated.',
    severity: 'blocked',
    educationTip: 'Are you being pressured? Legitimate entities never rush payments or threaten consequences.',
  },
  fraud_detected: {
    icon: Skull,
    title: '🛑 Fraud Detected - Transaction Blocked',
    description: 'This transaction has been identified as highly likely fraud. Your money is protected.',
    severity: 'blocked',
    educationTip: 'This receiver has been flagged in our fraud database. Do not proceed under any circumstances.',
  },
  behavioral_anomaly: {
    icon: Activity,
    title: 'Behavioral Anomaly Detected',
    description: 'Your current transaction behavior differs significantly from your normal patterns.',
    severity: 'suspicious',
    educationTip: 'Sudden changes in transaction behavior often indicate account compromise or coercion.',
  },
  rapid_transactions: {
    icon: Clock,
    title: 'Rapid Transaction Pattern',
    description: 'Multiple transactions in quick succession detected. This is often a sign of fraud.',
    severity: 'suspicious',
    educationTip: 'Slow down. Fraudsters create urgency to prevent victims from thinking clearly.',
  },
  new_device: {
    icon: AlertCircle,
    title: 'New Device Detected',
    description: 'This transaction is being made from an unrecognized device.',
    severity: 'suspicious',
    educationTip: 'Ensure this is your personal device and not a shared or public computer.',
  },
  night_transaction: {
    icon: Clock,
    title: 'Late Night Transaction',
    description: 'Transactions at unusual hours have higher fraud rates. Please verify this is intentional.',
    severity: 'suspicious',
    educationTip: 'Fraudsters often target victims during late hours when judgment is impaired.',
  },
};

interface WarningPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: () => void;
  warningType: WarningType;
  receiverName?: string;
  amount?: number;
  canProceed?: boolean;
}

export function WarningPopup({ 
  isOpen, 
  onClose, 
  onContinue, 
  warningType,
  receiverName, 
  amount,
  canProceed = true
}: WarningPopupProps) {
  const config = warningConfigs[warningType];
  const Icon = config.icon;
  const isBlocked = config.severity === 'blocked';

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-foreground/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-3xl shadow-xl border border-border overflow-hidden"
          >
            {/* Header */}
            <div className={`p-6 ${
              config.severity === 'blocked' ? 'gradient-danger' :
              config.severity === 'suspicious' ? 'gradient-warning' :
              'gradient-success'
            }`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 0.5, repeat: isBlocked ? Infinity : 0, repeatDelay: 1 }}
                    className="w-14 h-14 rounded-xl bg-card/20 backdrop-blur flex items-center justify-center"
                  >
                    <Icon className="w-7 h-7 text-primary-foreground" />
                  </motion.div>
                  <div>
                    <h3 className="font-display text-lg font-bold text-primary-foreground">
                      {config.title}
                    </h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      config.severity === 'blocked' ? 'bg-danger-foreground/20 text-danger-foreground' :
                      'bg-warning-foreground/20 text-warning-foreground'
                    }`}>
                      {config.severity === 'blocked' ? 'BLOCKED' : 'WARNING'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="w-8 h-8 rounded-lg bg-card/20 flex items-center justify-center hover:bg-card/30 transition-colors"
                >
                  <X className="w-4 h-4 text-primary-foreground" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              <p className="text-foreground text-lg">{config.description}</p>

              {(receiverName || amount) && (
                <div className="p-4 rounded-xl bg-muted/50 border border-border/50">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      {receiverName && (
                        <p className="font-medium text-foreground">{receiverName}</p>
                      )}
                      {amount && (
                        <p className="text-lg font-display font-bold text-foreground">
                          ₹{amount.toLocaleString('en-IN')}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {config.educationTip && (
                <div className="flex items-start gap-3 p-4 rounded-xl bg-primary/5 border border-primary/10">
                  <Shield className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-foreground mb-1">Safety Tip</p>
                    <p className="text-sm text-muted-foreground">{config.educationTip}</p>
                  </div>
                </div>
              )}

              {isBlocked && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center gap-3 p-4 rounded-xl bg-danger/10 border border-danger/20"
                >
                  <AlertTriangle className="w-6 h-6 text-danger" />
                  <p className="text-sm font-medium text-danger">
                    This transaction cannot proceed. Your account is protected.
                  </p>
                </motion.div>
              )}
            </div>

            {/* Actions */}
            <div className="p-6 pt-0 flex gap-3">
              <Button
                variant="outline"
                className="flex-1 h-12 rounded-xl"
                onClick={onClose}
              >
                {isBlocked ? 'Close' : 'Cancel Transaction'}
              </Button>
              {!isBlocked && canProceed && (
                <Button
                  className="flex-1 h-12 rounded-xl gradient-warning"
                  onClick={onContinue}
                >
                  I Understand, Continue
                </Button>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Fraud Education Card shown after blocked transactions
interface FraudEducationCardProps {
  isOpen: boolean;
  onClose: () => void;
  warningType: WarningType;
}

export function FraudEducationCard({ isOpen, onClose, warningType }: FraudEducationCardProps) {
  const tips = [
    "Never share OTP, PIN, or passwords with anyone, including bank officials.",
    "Verify the receiver's identity through a phone call before large transfers.",
    "Be wary of unsolicited calls claiming to be from banks or government.",
    "If pressured to act quickly, it's likely a scam. Take your time.",
    "Check for spelling errors in UPI IDs - fraudsters use similar-looking IDs.",
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-foreground/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-3xl shadow-xl border border-border overflow-hidden"
          >
            <div className="p-6 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-foreground">
                    Fraud Prevention Tips
                  </h3>
                  <p className="text-sm text-muted-foreground">Keep your money safe</p>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-3">
              {tips.map((tip, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 p-3 rounded-xl bg-muted/50"
                >
                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-primary">{index + 1}</span>
                  </div>
                  <p className="text-sm text-foreground">{tip}</p>
                </motion.div>
              ))}
            </div>

            <div className="p-6 pt-0">
              <Button onClick={onClose} className="w-full h-12 rounded-xl gradient-primary">
                Got It, Thanks!
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}