import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight, ArrowDownLeft, Clock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp, Transaction } from '@/contexts/AppContext';
import { RiskBadge } from '@/components/ui/RiskBadge';
import { cn } from '@/lib/utils';

interface TransactionItemProps {
  transaction: Transaction;
  index: number;
}

function TransactionItem({ transaction, index }: TransactionItemProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  const getIcon = () => {
    if (transaction.type === 'sent') return ArrowUpRight;
    if (transaction.type === 'received') return ArrowDownLeft;
    return Clock;
  };

  const Icon = getIcon();

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Link to={`/transaction/${transaction.id}`}>
        <motion.div
          whileHover={{ x: 4 }}
          whileTap={{ scale: 0.99 }}
          className="flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors"
        >
          <div className={cn(
            'w-10 h-10 rounded-xl flex items-center justify-center',
            transaction.type === 'sent' ? 'bg-danger/10' : 
            transaction.type === 'received' ? 'bg-success/10' : 'bg-warning/10'
          )}>
            <Icon className={cn(
              'w-5 h-5',
              transaction.type === 'sent' ? 'text-danger' : 
              transaction.type === 'received' ? 'text-success' : 'text-warning'
            )} />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-medium text-foreground truncate">{transaction.name}</p>
              <RiskBadge level={transaction.riskLevel} size="sm" showLabel={false} />
            </div>
            <p className="text-sm text-muted-foreground">{formatDate(transaction.date)}</p>
          </div>

          <div className="text-right flex items-center gap-2">
            <div>
              <p className={cn(
                'font-semibold',
                transaction.type === 'sent' ? 'text-danger' : 
                transaction.type === 'received' ? 'text-success' : 'text-foreground'
              )}>
                {transaction.type === 'sent' ? '-' : '+'}{formatCurrency(transaction.amount)}
              </p>
              <p className="text-xs text-muted-foreground">
                {transaction.fraudProbability}% risk
              </p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </div>
        </motion.div>
      </Link>
    </motion.div>
  );
}

export function TransactionList() {
  const { transactions } = useApp();
  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-1">
        <h3 className="font-display font-semibold text-foreground">Recent Transactions</h3>
        <Link to="/history" className="text-sm text-primary font-medium">
          View All
        </Link>
      </div>

      <div className="bg-card rounded-2xl border border-border/50 divide-y divide-border/50">
        <AnimatePresence>
          {recentTransactions.map((transaction, index) => (
            <TransactionItem key={transaction.id} transaction={transaction} index={index} />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
