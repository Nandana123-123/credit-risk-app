import { motion } from 'framer-motion';
import { Shield, AlertTriangle, TrendingDown, Brain } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { FraudMeter } from '@/components/ui/FraudMeter';

export function FraudStatusCard() {
  const { transactions, demoMode } = useApp();
  
  // Calculate overall risk based on transactions and demo mode
  const getOverallRisk = () => {
    if (demoMode === 'fraudster') return 85;
    if (demoMode === 'victim') return 65;
    
    const blockedCount = transactions.filter(t => t.riskLevel === 'blocked').length;
    const suspiciousCount = transactions.filter(t => t.riskLevel === 'suspicious').length;
    
    return Math.min(95, 10 + (blockedCount * 15) + (suspiciousCount * 8));
  };

  const overallRisk = getOverallRisk();
  const blockedThisMonth = transactions.filter(t => t.status === 'blocked').length;
  const moneyProtected = transactions
    .filter(t => t.status === 'blocked')
    .reduce((sum, t) => sum + t.amount, 0);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="bg-card rounded-2xl border border-border/50 p-5"
    >
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <Brain className="w-4 h-4 text-primary" />
        </div>
        <h3 className="font-display font-semibold text-foreground">AI Fraud Monitor</h3>
      </div>

      <FraudMeter probability={overallRisk} className="mb-4" />

      <div className="grid grid-cols-2 gap-3">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="p-3 rounded-xl bg-danger/5 border border-danger/10"
        >
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-danger" />
            <span className="text-xs font-medium text-danger">Blocked</span>
          </div>
          <p className="text-xl font-bold text-foreground">{blockedThisMonth}</p>
          <p className="text-xs text-muted-foreground">This month</p>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className="p-3 rounded-xl bg-success/5 border border-success/10"
        >
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-4 h-4 text-success" />
            <span className="text-xs font-medium text-success">Protected</span>
          </div>
          <p className="text-xl font-bold text-foreground">{formatCurrency(moneyProtected)}</p>
          <p className="text-xs text-muted-foreground">Money saved</p>
        </motion.div>
      </div>
    </motion.div>
  );
}
