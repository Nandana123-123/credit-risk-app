import { motion } from 'framer-motion';
import { User, Target, Shield } from 'lucide-react';
import { useApp, DemoMode } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';

const modes: { value: DemoMode; label: string; icon: typeof User; description: string }[] = [
  { value: 'normal', label: 'Normal', icon: User, description: 'Regular user experience' },
  { value: 'victim', label: 'Victim', icon: Target, description: 'Simulate fraud victim' },
  { value: 'fraudster', label: 'Fraudster', icon: Shield, description: 'Test fraud detection' },
];

export function DemoModeToggle() {
  const { demoMode, setDemoMode } = useApp();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="bg-card rounded-2xl border border-border/50 p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-display font-semibold text-foreground text-sm">Demo Mode</h3>
        <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary font-medium">
          Testing
        </span>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {modes.map((mode) => {
          const Icon = mode.icon;
          const isActive = demoMode === mode.value;

          return (
            <motion.button
              key={mode.value}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setDemoMode(mode.value)}
              className={cn(
                'relative p-3 rounded-xl border transition-all text-center',
                isActive
                  ? 'border-primary bg-primary/5'
                  : 'border-border/50 hover:border-border'
              )}
            >
              {isActive && (
                <motion.div
                  layoutId="demoModeIndicator"
                  className="absolute inset-0 rounded-xl border-2 border-primary"
                />
              )}
              <Icon className={cn(
                'w-5 h-5 mx-auto mb-1',
                isActive ? 'text-primary' : 'text-muted-foreground'
              )} />
              <span className={cn(
                'text-xs font-medium block',
                isActive ? 'text-primary' : 'text-muted-foreground'
              )}>
                {mode.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
}
