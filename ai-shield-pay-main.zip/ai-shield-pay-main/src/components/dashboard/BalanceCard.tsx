import { motion } from 'framer-motion';
import { Eye, EyeOff, TrendingUp, Shield } from 'lucide-react';
import { useState } from 'react';
import { useApp } from '@/contexts/AppContext';

export function BalanceCard() {
  const { balance } = useApp();
  const [showBalance, setShowBalance] = useState(true);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-3xl gradient-primary p-6 shadow-glow"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-40 h-40 bg-primary-foreground rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-primary-foreground rounded-full translate-y-1/2 -translate-x-1/2" />
      </div>

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary-foreground/20 flex items-center justify-center">
              <Shield className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-primary-foreground/80 text-sm font-medium">
              Protected Balance
            </span>
          </div>
          <button
            onClick={() => setShowBalance(!showBalance)}
            className="w-8 h-8 rounded-lg bg-primary-foreground/20 flex items-center justify-center hover:bg-primary-foreground/30 transition-colors"
          >
            {showBalance ? (
              <Eye className="w-4 h-4 text-primary-foreground" />
            ) : (
              <EyeOff className="w-4 h-4 text-primary-foreground" />
            )}
          </button>
        </div>

        <motion.div
          key={showBalance ? 'visible' : 'hidden'}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-4"
        >
          <h2 className="font-display text-4xl font-bold text-primary-foreground">
            {showBalance ? formatCurrency(balance) : '₹ ••••••'}
          </h2>
        </motion.div>

        <div className="flex items-center gap-2 text-primary-foreground/80">
          <TrendingUp className="w-4 h-4" />
          <span className="text-sm">+₹2,500 this month</span>
        </div>
      </div>
    </motion.div>
  );
}
