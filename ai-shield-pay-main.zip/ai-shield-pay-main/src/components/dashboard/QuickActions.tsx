import { motion } from 'framer-motion';
import { Send, Download, QrCode, Smartphone, Wallet, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

const actions = [
  { icon: Send, label: 'Pay', path: '/pay', color: 'bg-primary' },
  { icon: Download, label: 'Request', path: '/request', color: 'bg-success' },
  { icon: QrCode, label: 'Scan QR', path: '/scan', color: 'bg-accent' },
  { icon: Smartphone, label: 'Recharge', path: '/recharge', color: 'bg-warning' },
  { icon: Wallet, label: 'Bills', path: '/bills', color: 'bg-danger' },
  { icon: Shield, label: 'Safe Pay', path: '/safe-pay', color: 'bg-safe' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function QuickActions() {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-3 gap-4"
    >
      {actions.map((action) => {
        const Icon = action.icon;
        return (
          <motion.div key={action.label} variants={itemVariants}>
            <Link to={action.path}>
              <motion.div
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-card border border-border/50 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', action.color)}>
                  <Icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <span className="text-sm font-medium text-foreground">{action.label}</span>
              </motion.div>
            </Link>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
