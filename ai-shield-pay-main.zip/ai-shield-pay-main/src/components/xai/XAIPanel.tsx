import { motion, AnimatePresence } from 'framer-motion';
import { X, Brain, TrendingUp, AlertTriangle, Cpu, Network, Mic } from 'lucide-react';
import type { Transaction } from '@/contexts/AppContext';

interface XAIPanelProps {
  isOpen: boolean;
  onClose: () => void;
  transaction?: Transaction;
}

const factorConfig = {
  behaviour: { icon: TrendingUp, label: 'Behaviour Analysis', description: 'User spending patterns and timing' },
  amountAnomaly: { icon: AlertTriangle, label: 'Amount Anomaly', description: 'Unusual transaction amount detected' },
  deviceRisk: { icon: Cpu, label: 'Device Risk', description: 'Device fingerprint and security' },
  graphRisk: { icon: Network, label: 'Graph Analysis', description: 'Network connection patterns' },
  voiceNlpRisk: { icon: Mic, label: 'Voice/NLP Analysis', description: 'Communication pattern analysis' },
};

export function XAIPanel({ isOpen, onClose, transaction }: XAIPanelProps) {
  if (!transaction?.riskFactors) return null;

  const getExplanation = () => {
    const factors = transaction.riskFactors!;
    const highRiskFactors = Object.entries(factors)
      .filter(([_, value]) => value > 20)
      .sort((a, b) => b[1] - a[1]);

    if (transaction.riskLevel === 'blocked') {
      return `This transaction was blocked because our AI detected a ${transaction.fraudProbability}% probability of fraud. The primary concerns were ${highRiskFactors.map(([k]) => factorConfig[k as keyof typeof factorConfig].label.toLowerCase()).join(', ')}.`;
    }
    if (transaction.riskLevel === 'suspicious') {
      return `This transaction was flagged as suspicious with a ${transaction.fraudProbability}% fraud probability. We recommend additional verification.`;
    }
    return `This transaction was marked as safe with only ${transaction.fraudProbability}% fraud probability. All risk factors were within normal limits.`;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-foreground/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-card rounded-3xl shadow-xl border border-border overflow-hidden max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="sticky top-0 p-6 border-b border-border bg-card z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                    <Brain className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-bold text-foreground">
                      Explainable AI Analysis
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Why was this decision made?
                    </p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                >
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>
            </div>

            {/* Explanation */}
            <div className="p-6 space-y-6">
              <div className={`p-4 rounded-xl border ${
                transaction.riskLevel === 'safe' ? 'bg-success/5 border-success/20' :
                transaction.riskLevel === 'suspicious' ? 'bg-warning/5 border-warning/20' :
                'bg-danger/5 border-danger/20'
              }`}>
                <p className="text-foreground leading-relaxed">{getExplanation()}</p>
              </div>

              {/* Risk Factor Breakdown */}
              <div className="space-y-4">
                <h4 className="font-display font-semibold text-foreground">
                  Feature Contribution Analysis
                </h4>

                {Object.entries(transaction.riskFactors!).map(([key, value], index) => {
                  const config = factorConfig[key as keyof typeof factorConfig];
                  const Icon = config.icon;

                  return (
                    <motion.div
                      key={key}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 rounded-xl bg-muted/50 border border-border/50"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                          value < 20 ? 'bg-success/10' :
                          value < 50 ? 'bg-warning/10' :
                          'bg-danger/10'
                        }`}>
                          <Icon className={`w-5 h-5 ${
                            value < 20 ? 'text-success' :
                            value < 50 ? 'text-warning' :
                            'text-danger'
                          }`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-foreground">{config.label}</span>
                            <span className={`font-bold ${
                              value < 20 ? 'text-success' :
                              value < 50 ? 'text-warning' :
                              'text-danger'
                            }`}>
                              {value}%
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{config.description}</p>
                          <div className="h-2 bg-background rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${value}%` }}
                              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                              className={`h-full rounded-full ${
                                value < 20 ? 'bg-safe' : value < 50 ? 'bg-suspicious' : 'bg-blocked'
                              }`}
                            />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Ethics Note */}
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                <p className="text-sm text-muted-foreground">
                  <strong className="text-foreground">Ethical AI Commitment:</strong> Our fraud detection 
                  system is designed to be transparent, fair, and accountable. We continuously monitor 
                  for bias and work to ensure equitable treatment for all users.
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
