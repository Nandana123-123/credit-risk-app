import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Lock, Eye, EyeOff, Check, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface SecurityPasswordSetupProps {
  isOpen: boolean;
  onComplete: (password: string) => void;
}

export function SecurityPasswordSetup({ isOpen, onComplete }: SecurityPasswordSetupProps) {
  const [step, setStep] = useState<'intro' | 'create' | 'confirm'>('intro');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleCreatePassword = () => {
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    setError('');
    setStep('confirm');
  };

  const handleConfirmPassword = () => {
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    onComplete(password);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-foreground/60 backdrop-blur-md"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="w-full max-w-md bg-card rounded-3xl shadow-2xl border border-border overflow-hidden"
          >
            {step === 'intro' && (
              <div className="p-8 space-y-6">
                <div className="text-center space-y-4">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', damping: 10, delay: 0.2 }}
                    className="w-20 h-20 rounded-2xl gradient-primary flex items-center justify-center mx-auto"
                  >
                    <Shield className="w-10 h-10 text-primary-foreground" />
                  </motion.div>
                  
                  <h2 className="font-display text-2xl font-bold text-foreground">
                    Set Up Security Password
                  </h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Create a secure password to protect your transactions. This password will be required every time you make a payment.
                  </p>
                </div>

                <div className="space-y-3 p-4 bg-muted/50 rounded-2xl">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
                      <Check className="w-4 h-4 text-success" />
                    </div>
                    <span className="text-sm text-foreground">Protection against unauthorized payments</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
                      <Check className="w-4 h-4 text-success" />
                    </div>
                    <span className="text-sm text-foreground">AI-powered fraud detection layer</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
                      <Check className="w-4 h-4 text-success" />
                    </div>
                    <span className="text-sm text-foreground">Real-time transaction monitoring</span>
                  </div>
                </div>

                <Button
                  onClick={() => setStep('create')}
                  className="w-full h-14 rounded-2xl text-lg gradient-primary"
                >
                  Create Password
                </Button>
              </div>
            )}

            {step === 'create' && (
              <div className="p-8 space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Lock className="w-8 h-8 text-primary" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-foreground">Create Password</h2>
                  <p className="text-muted-foreground">Enter a strong password (min 6 characters)</p>
                </div>

                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError('');
                    }}
                    className="h-14 text-lg pr-12 rounded-2xl"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {error && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-sm text-danger flex items-center gap-2"
                  >
                    <AlertTriangle className="w-4 h-4" />
                    {error}
                  </motion.p>
                )}

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${password.length >= 6 ? 'bg-success' : 'bg-muted'}`} />
                    <span className={`text-sm ${password.length >= 6 ? 'text-success' : 'text-muted-foreground'}`}>
                      At least 6 characters
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${/[A-Z]/.test(password) ? 'bg-success' : 'bg-muted'}`} />
                    <span className={`text-sm ${/[A-Z]/.test(password) ? 'text-success' : 'text-muted-foreground'}`}>
                      Contains uppercase letter
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${/[0-9]/.test(password) ? 'bg-success' : 'bg-muted'}`} />
                    <span className={`text-sm ${/[0-9]/.test(password) ? 'text-success' : 'text-muted-foreground'}`}>
                      Contains a number
                    </span>
                  </div>
                </div>

                <Button
                  onClick={handleCreatePassword}
                  disabled={password.length < 6}
                  className="w-full h-14 rounded-2xl text-lg gradient-primary"
                >
                  Continue
                </Button>
              </div>
            )}

            {step === 'confirm' && (
              <div className="p-8 space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 rounded-2xl bg-success/10 flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8 text-success" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-foreground">Confirm Password</h2>
                  <p className="text-muted-foreground">Re-enter your password to confirm</p>
                </div>

                <Input
                  type="password"
                  placeholder="Confirm password"
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    setError('');
                  }}
                  className="h-14 text-lg rounded-2xl"
                />

                {error && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-sm text-danger flex items-center gap-2"
                  >
                    <AlertTriangle className="w-4 h-4" />
                    {error}
                  </motion.p>
                )}

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setStep('create');
                      setConfirmPassword('');
                      setError('');
                    }}
                    className="flex-1 h-12 rounded-xl"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleConfirmPassword}
                    disabled={!confirmPassword}
                    className="flex-1 h-12 rounded-xl gradient-primary"
                  >
                    Complete Setup
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}