import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProvider } from "@/contexts/AppContext";
import HomePage from "./pages/HomePage";
import PayPage from "./pages/PayPage";
import HistoryPage from "./pages/HistoryPage";
import RequestPage from "./pages/RequestPage";
import ScanPage from "./pages/ScanPage";
import SafePayPage from "./pages/SafePayPage";
import ProfilePage from "./pages/ProfilePage";
import AdminDashboard from "./pages/AdminDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AppProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/pay" element={<PayPage />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/request" element={<RequestPage />} />
            <Route path="/scan" element={<ScanPage />} />
            <Route path="/safe-pay" element={<SafePayPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/recharge" element={<HomePage />} />
            <Route path="/bills" element={<HomePage />} />
            <Route path="/transaction/:id" element={<HistoryPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AppProvider>
  </QueryClientProvider>
);

export default App;