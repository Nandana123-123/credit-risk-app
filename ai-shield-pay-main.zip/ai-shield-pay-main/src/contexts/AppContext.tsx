import React, { createContext, useContext, useState, ReactNode } from 'react';

export type DemoMode = 'normal' | 'victim' | 'fraudster';
export type RiskLevel = 'safe' | 'suspicious' | 'blocked';

export interface Transaction {
  id: string;
  type: 'sent' | 'received' | 'request';
  amount: number;
  name: string;
  upiId: string;
  date: Date;
  riskLevel: RiskLevel;
  fraudProbability: number;
  status: 'completed' | 'pending' | 'blocked';
  riskFactors?: {
    behaviour: number;
    amountAnomaly: number;
    deviceRisk: number;
    graphRisk: number;
    voiceNlpRisk: number;
  };
}

interface AppContextType {
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
  demoMode: DemoMode;
  setDemoMode: (mode: DemoMode) => void;
  balance: number;
  setBalance: (value: number) => void;
  transactions: Transaction[];
  addTransaction: (transaction: Transaction) => void;
  safePayMode: {
    enabled: boolean;
    maxAmount: number;
    allowedContacts: string[];
    timeWindow: number;
  };
  setSafePayMode: (mode: AppContextType['safePayMode']) => void;
  securityPassword: string | null;
  setSecurityPassword: (password: string) => void;
  isPasswordSet: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [darkMode, setDarkMode] = useState(false);
  const [demoMode, setDemoMode] = useState<DemoMode>('normal');
  const [balance, setBalance] = useState(25000);
  const [safePayMode, setSafePayMode] = useState({
    enabled: false,
    maxAmount: 1000,
    allowedContacts: [],
    timeWindow: 24,
  });
  const [securityPassword, setSecurityPasswordState] = useState<string | null>(() => {
    // Check localStorage for existing password
    const saved = localStorage.getItem('rakshapay_security_password');
    return saved;
  });

  const setSecurityPassword = (password: string) => {
    localStorage.setItem('rakshapay_security_password', password);
    setSecurityPasswordState(password);
  };

  const isPasswordSet = securityPassword !== null;

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      type: 'sent',
      amount: 500,
      name: 'Rahul Sharma',
      upiId: 'rahul@upi',
      date: new Date(Date.now() - 86400000),
      riskLevel: 'safe',
      fraudProbability: 5,
      status: 'completed',
      riskFactors: { behaviour: 2, amountAnomaly: 1, deviceRisk: 1, graphRisk: 0, voiceNlpRisk: 1 },
    },
    {
      id: '2',
      type: 'received',
      amount: 2500,
      name: 'Priya Patel',
      upiId: 'priya@upi',
      date: new Date(Date.now() - 172800000),
      riskLevel: 'safe',
      fraudProbability: 3,
      status: 'completed',
      riskFactors: { behaviour: 1, amountAnomaly: 0, deviceRisk: 1, graphRisk: 0, voiceNlpRisk: 1 },
    },
    {
      id: '3',
      type: 'sent',
      amount: 15000,
      name: 'Unknown Seller',
      upiId: 'seller123@upi',
      date: new Date(Date.now() - 259200000),
      riskLevel: 'suspicious',
      fraudProbability: 65,
      status: 'completed',
      riskFactors: { behaviour: 25, amountAnomaly: 20, deviceRisk: 10, graphRisk: 5, voiceNlpRisk: 5 },
    },
    {
      id: '4',
      type: 'sent',
      amount: 50000,
      name: 'Fake Investment',
      upiId: 'invest@scam',
      date: new Date(Date.now() - 345600000),
      riskLevel: 'blocked',
      fraudProbability: 92,
      status: 'blocked',
      riskFactors: { behaviour: 30, amountAnomaly: 25, deviceRisk: 15, graphRisk: 12, voiceNlpRisk: 10 },
    },
    {
      id: '5',
      type: 'request',
      amount: 1000,
      name: 'Amit Kumar',
      upiId: 'amit@upi',
      date: new Date(Date.now() - 432000000),
      riskLevel: 'safe',
      fraudProbability: 8,
      status: 'pending',
      riskFactors: { behaviour: 3, amountAnomaly: 2, deviceRisk: 1, graphRisk: 1, voiceNlpRisk: 1 },
    },
  ]);

  const addTransaction = (transaction: Transaction) => {
    setTransactions((prev) => [transaction, ...prev]);
  };

  React.useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <AppContext.Provider
      value={{
        darkMode,
        setDarkMode,
        demoMode,
        setDemoMode,
        balance,
        setBalance,
        transactions,
        addTransaction,
        safePayMode,
        setSafePayMode,
        securityPassword,
        setSecurityPassword,
        isPasswordSet,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
