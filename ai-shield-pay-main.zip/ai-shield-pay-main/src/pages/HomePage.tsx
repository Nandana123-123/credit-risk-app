import { motion } from 'framer-motion';
import { Layout } from '@/components/layout/Layout';
import { BalanceCard } from '@/components/dashboard/BalanceCard';
import { QuickActions } from '@/components/dashboard/QuickActions';
import { TransactionList } from '@/components/dashboard/TransactionList';
import { FraudStatusCard } from '@/components/dashboard/FraudStatusCard';
import { DemoModeToggle } from '@/components/dashboard/DemoModeToggle';

const HomePage = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <BalanceCard />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="font-display font-semibold text-foreground mb-3">Quick Actions</h3>
          <QuickActions />
        </motion.div>

        <FraudStatusCard />
        
        <DemoModeToggle />

        <TransactionList />
      </div>
    </Layout>
  );
};

export default HomePage;