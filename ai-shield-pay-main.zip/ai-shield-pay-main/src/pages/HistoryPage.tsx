import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight, ArrowDownLeft, Clock, Filter, Calendar, Brain } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { RiskBadge } from '@/components/ui/RiskBadge';
import { XAIPanel } from '@/components/xai/XAIPanel';
import { useApp, Transaction, RiskLevel } from '@/contexts/AppContext';
import { cn } from '@/lib/utils';

const HistoryPage = () => {
  const { transactions } = useApp();
  const [filter, setFilter] = useState<'all' | 'sent' | 'received' | 'blocked'>('all');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [showXAI, setShowXAI] = useState(false);

  const filteredTransactions = transactions.filter((t) => {
    if (filter === 'all') return true;
    if (filter === 'blocked') return t.status === 'blocked';
    return t.type === filter;
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const getIcon = (type: string) => {
    if (type === 'sent') return ArrowUpRight;
    if (type === 'received') return ArrowDownLeft;
    return Clock;
  };

  const handleViewXAI = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setShowXAI(true);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="font-display text-2xl font-bold text-foreground">Transaction History</h1>
            <p className="text-muted-foreground">View all your transactions with AI risk analysis</p>
          </div>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide"
        >
          {(['all', 'sent', 'received', 'blocked'] as const).map((f) => (
            <Button
              key={f}
              variant={filter === f ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(f)}
              className={cn('rounded-full capitalize shrink-0', filter === f && 'gradient-primary')}
            >
              {f === 'blocked' && <Filter className="w-3 h-3 mr-1" />}
              {f}
            </Button>
          ))}
        </motion.div>

        {/* Transaction List */}
        <div className="space-y-3">
          <AnimatePresence>
            {filteredTransactions.map((transaction, index) => {
              const Icon = getIcon(transaction.type);

              return (
                <motion.div
                  key={transaction.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-card rounded-2xl border border-border/50 p-4"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center shrink-0',
                      transaction.type === 'sent' ? 'bg-danger/10' : 
                      transaction.type === 'received' ? 'bg-success/10' : 'bg-warning/10'
                    )}>
                      <Icon className={cn(
                        'w-6 h-6',
                        transaction.type === 'sent' ? 'text-danger' : 
                        transaction.type === 'received' ? 'text-success' : 'text-warning'
                      )} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-foreground truncate">{transaction.name}</p>
                        <RiskBadge level={transaction.riskLevel} size="sm" showLabel={false} />
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        <span>{formatDate(transaction.date)}</span>
                        <span>•</span>
                        <span>{transaction.fraudProbability}% risk</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className={cn(
                        'font-display text-lg font-bold',
                        transaction.type === 'sent' ? 'text-danger' : 
                        transaction.type === 'received' ? 'text-success' : 'text-foreground'
                      )}>
                        {transaction.type === 'sent' ? '-' : '+'}{formatCurrency(transaction.amount)}
                      </p>
                      <span className={cn(
                        'text-xs px-2 py-0.5 rounded-full',
                        transaction.status === 'completed' ? 'bg-success/10 text-success' :
                        transaction.status === 'blocked' ? 'bg-danger/10 text-danger' :
                        'bg-warning/10 text-warning'
                      )}>
                        {transaction.status}
                      </span>
                    </div>
                  </div>

                  {/* View XAI Button */}
                  <div className="mt-3 pt-3 border-t border-border/50 flex justify-end">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewXAI(transaction)}
                      className="gap-2 text-primary"
                    >
                      <Brain className="w-4 h-4" />
                      View AI Analysis
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {filteredTransactions.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <p className="text-muted-foreground">No transactions found</p>
            </motion.div>
          )}
        </div>
      </div>

      <XAIPanel
        isOpen={showXAI}
        onClose={() => setShowXAI(false)}
        transaction={selectedTransaction || undefined}
      />
    </Layout>
  );
};

export default HistoryPage;