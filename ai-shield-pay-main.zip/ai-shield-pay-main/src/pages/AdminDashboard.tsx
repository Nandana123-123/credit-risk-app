import { motion } from 'framer-motion';
import { 
  Activity, 
  Users, 
  AlertTriangle, 
  Shield, 
  TrendingUp, 
  MapPin,
  Clock,
  Brain,
  Mic,
  Network,
  Cpu
} from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { FraudMeter } from '@/components/ui/FraudMeter';
import { RiskBadge } from '@/components/ui/RiskBadge';
import { useApp } from '@/contexts/AppContext';

const AdminDashboard = () => {
  const { transactions } = useApp();

  const stats = {
    totalTransactions: transactions.length,
    blocked: transactions.filter(t => t.status === 'blocked').length,
    suspicious: transactions.filter(t => t.riskLevel === 'suspicious').length,
    safe: transactions.filter(t => t.riskLevel === 'safe').length,
    moneyProtected: transactions.filter(t => t.status === 'blocked').reduce((sum, t) => sum + t.amount, 0),
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Mock data for visualizations
  const heatmapData = [
    { hour: '00-04', risk: 15 },
    { hour: '04-08', risk: 25 },
    { hour: '08-12', risk: 45 },
    { hour: '12-16', risk: 60 },
    { hour: '16-20', risk: 75 },
    { hour: '20-24', risk: 35 },
  ];

  const fraudClusters = [
    { id: 1, name: 'Investment Scams', count: 45, risk: 92 },
    { id: 2, name: 'Tech Support', count: 32, risk: 78 },
    { id: 3, name: 'Lottery Fraud', count: 28, risk: 85 },
    { id: 4, name: 'Romance Scams', count: 18, risk: 70 },
  ];

  const deepfakeLogs = [
    { id: 1, type: 'Voice Clone', detected: true, confidence: 94 },
    { id: 2, type: 'Video Deepfake', detected: false, confidence: 12 },
    { id: 3, type: 'Voice Clone', detected: true, confidence: 87 },
  ];

  const regionalData = [
    { region: 'Maharashtra', victims: 1250, fraudsters: 89, risk: 45 },
    { region: 'Delhi NCR', victims: 980, fraudsters: 156, risk: 62 },
    { region: 'Karnataka', victims: 750, fraudsters: 45, risk: 35 },
    { region: 'Tamil Nadu', victims: 620, fraudsters: 67, risk: 42 },
    { region: 'Gujarat', victims: 540, fraudsters: 78, risk: 55 },
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-foreground">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Judge/Demo View - Fraud Analytics</p>
            </div>
          </div>
        </motion.div>

        {/* Live Fraud Risk Meter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-2xl border border-border p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-primary" />
            <h2 className="font-display font-semibold text-foreground">Live System Risk Level</h2>
            <span className="ml-auto text-xs px-2 py-1 rounded-full bg-success/10 text-success animate-pulse">
              LIVE
            </span>
          </div>
          <FraudMeter probability={42} size="lg" animated />
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4"
        >
          <div className="bg-card rounded-2xl border border-border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-primary" />
              </div>
            </div>
            <p className="text-2xl font-display font-bold text-foreground">{stats.totalTransactions}</p>
            <p className="text-sm text-muted-foreground">Total Transactions</p>
          </div>

          <div className="bg-card rounded-2xl border border-border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-danger/10 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-danger" />
              </div>
            </div>
            <p className="text-2xl font-display font-bold text-foreground">{stats.blocked}</p>
            <p className="text-sm text-muted-foreground">Blocked</p>
          </div>

          <div className="bg-card rounded-2xl border border-border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-warning/10 flex items-center justify-center">
                <Users className="w-4 h-4 text-warning" />
              </div>
            </div>
            <p className="text-2xl font-display font-bold text-foreground">{stats.suspicious}</p>
            <p className="text-sm text-muted-foreground">Suspicious</p>
          </div>

          <div className="bg-card rounded-2xl border border-border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
                <Shield className="w-4 h-4 text-success" />
              </div>
            </div>
            <p className="text-2xl font-display font-bold text-foreground">{formatCurrency(stats.moneyProtected)}</p>
            <p className="text-sm text-muted-foreground">Protected</p>
          </div>
        </motion.div>

        {/* Behaviour Anomaly Heatmap */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-2xl border border-border p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-primary" />
            <h2 className="font-display font-semibold text-foreground">Behaviour Anomaly Heatmap</h2>
          </div>
          <div className="grid grid-cols-6 gap-2">
            {heatmapData.map((data, i) => (
              <motion.div
                key={data.hour}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + i * 0.05 }}
                className="text-center"
              >
                <div
                  className="h-20 rounded-xl mb-2 flex items-end justify-center transition-all"
                  style={{
                    background: `linear-gradient(to top, 
                      hsl(${120 - data.risk * 1.2}, 70%, 50%) 0%, 
                      hsl(${120 - data.risk * 1.2}, 70%, 50%, 0.2) 100%)`,
                  }}
                >
                  <span className="text-xs font-bold text-primary-foreground pb-2">{data.risk}%</span>
                </div>
                <span className="text-xs text-muted-foreground">{data.hour}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Fraud Cluster Graph */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="bg-card rounded-2xl border border-border p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Network className="w-5 h-5 text-primary" />
            <h2 className="font-display font-semibold text-foreground">Fraud Cluster Analysis</h2>
          </div>
          <div className="space-y-3">
            {fraudClusters.map((cluster, i) => (
              <motion.div
                key={cluster.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.05 }}
                className="flex items-center gap-4 p-3 rounded-xl bg-muted/50"
              >
                <div className="w-10 h-10 rounded-xl gradient-danger flex items-center justify-center shrink-0">
                  <Brain className="w-5 h-5 text-danger-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground">{cluster.name}</p>
                  <p className="text-sm text-muted-foreground">{cluster.count} incidents detected</p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-bold text-danger">{cluster.risk}%</span>
                  <p className="text-xs text-muted-foreground">risk score</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Deepfake Detection Logs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-2xl border border-border p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Mic className="w-5 h-5 text-primary" />
            <h2 className="font-display font-semibold text-foreground">Deepfake Detection Logs</h2>
          </div>
          <div className="space-y-2">
            {deepfakeLogs.map((log, i) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.35 + i * 0.05 }}
                className="flex items-center justify-between p-3 rounded-xl border border-border/50"
              >
                <div className="flex items-center gap-3">
                  <Cpu className={`w-4 h-4 ${log.detected ? 'text-danger' : 'text-success'}`} />
                  <span className="text-sm text-foreground">{log.type}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{log.confidence}%</span>
                  <RiskBadge 
                    level={log.detected ? 'blocked' : 'safe'} 
                    size="sm" 
                    showLabel 
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* National Fraud Heatmap */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="bg-card rounded-2xl border border-border p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-5 h-5 text-primary" />
            <h2 className="font-display font-semibold text-foreground">Regional Fraud Statistics</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground">Region</th>
                  <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Victims</th>
                  <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Fraudsters</th>
                  <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Risk Level</th>
                </tr>
              </thead>
              <tbody>
                {regionalData.map((region, i) => (
                  <motion.tr
                    key={region.region}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 + i * 0.05 }}
                    className="border-b border-border/50"
                  >
                    <td className="py-3 px-2 font-medium text-foreground">{region.region}</td>
                    <td className="py-3 px-2 text-right text-muted-foreground">{region.victims.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right text-danger">{region.fraudsters}</td>
                    <td className="py-3 px-2 text-right">
                      <div className="w-full max-w-20 h-2 bg-muted rounded-full overflow-hidden ml-auto">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${region.risk}%` }}
                          transition={{ duration: 0.5, delay: 0.5 + i * 0.05 }}
                          className={`h-full rounded-full ${
                            region.risk < 40 ? 'bg-safe' : region.risk < 60 ? 'bg-suspicious' : 'bg-blocked'
                          }`}
                        />
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
};

export default AdminDashboard;