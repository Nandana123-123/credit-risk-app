import { motion } from 'framer-motion';
import { QrCode, Camera } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';

const ScanPage = () => {
  const navigate = useNavigate();

  return (
    <Layout showNav={false}>
      <div className="container mx-auto px-4 py-6 min-h-screen flex flex-col">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1 flex flex-col items-center justify-center space-y-8"
        >
          <div className="relative">
            <motion.div
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.5, 0.3, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="absolute inset-0 w-64 h-64 rounded-3xl gradient-primary"
            />
            <div className="relative w-64 h-64 rounded-3xl bg-card border-4 border-primary flex items-center justify-center">
              <div className="absolute inset-4 border-2 border-dashed border-primary/50 rounded-2xl" />
              <QrCode className="w-20 h-20 text-primary" />
            </div>
          </div>

          <div className="text-center space-y-2">
            <h2 className="font-display text-2xl font-bold text-foreground">Scan QR Code</h2>
            <p className="text-muted-foreground">Point your camera at a QR code to pay</p>
          </div>

          <div className="w-full max-w-xs space-y-3">
            <Button
              className="w-full h-14 rounded-2xl text-lg gradient-primary gap-2"
            >
              <Camera className="w-5 h-5" />
              Open Camera
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              Camera access simulation - Demo mode
            </p>
          </div>
        </motion.div>

        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mt-8"
        >
          Cancel
        </Button>
      </div>
    </Layout>
  );
};

export default ScanPage;