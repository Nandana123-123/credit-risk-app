import { motion } from 'framer-motion';
import { useState } from 'react';
import { ArrowLeft, Copy, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

const RequestPage = () => {
  const navigate = useNavigate();
  const { addTransaction } = useApp();
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [isCreated, setIsCreated] = useState(false);

  const handleCreateRequest = () => {
    if (!amount || parseFloat(amount) <= 0) return;

    addTransaction({
      id: Date.now().toString(),
      type: 'request',
      amount: parseFloat(amount),
      name: 'Payment Request',
      upiId: 'you@upi',
      date: new Date(),
      riskLevel: 'safe',
      fraudProbability: 5,
      status: 'pending',
      riskFactors: { behaviour: 2, amountAnomaly: 1, deviceRisk: 1, graphRisk: 0, voiceNlpRisk: 1 },
    });

    setIsCreated(true);
    toast({
      title: 'Request Created',
      description: `Payment request for ₹${parseFloat(amount).toLocaleString('en-IN')} has been created.`,
    });
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`rakshapay://pay?amount=${amount}`);
    toast({
      title: 'Link Copied',
      description: 'Payment link has been copied to clipboard.',
    });
  };

  return (
    <Layout showNav={false}>
      <div className="container mx-auto px-4 py-6 min-h-screen">
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-muted-foreground mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </motion.button>

        {!isCreated ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">Request Payment</h2>
              <p className="text-muted-foreground">Create a payment request</p>
            </div>

            <div className="space-y-4">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl text-muted-foreground">₹</span>
                <Input
                  type="number"
                  placeholder="0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="h-20 text-4xl font-display font-bold text-center rounded-2xl pl-10"
                />
              </div>

              <Input
                type="text"
                placeholder="Add a note (optional)"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="h-14 rounded-2xl"
              />

              <Button
                onClick={handleCreateRequest}
                disabled={!amount || parseFloat(amount) <= 0}
                className="w-full h-14 rounded-2xl text-lg gradient-success"
              >
                Create Request
              </Button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6 text-center"
          >
            <div className="w-20 h-20 rounded-3xl gradient-success flex items-center justify-center mx-auto shadow-success-glow">
              <Download className="w-10 h-10 text-success-foreground" />
            </div>

            <div className="space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">Request Created!</h2>
              <p className="text-muted-foreground">
                Share this link to receive ₹{parseFloat(amount).toLocaleString('en-IN')}
              </p>
            </div>

            <div className="bg-card rounded-2xl border border-border p-4">
              <p className="font-mono text-sm text-foreground break-all">
                rakshapay://pay?amount={amount}
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={handleCopyLink}
                className="flex-1 h-12 rounded-xl gap-2"
              >
                <Copy className="w-4 h-4" />
                Copy Link
              </Button>
              <Button
                onClick={() => navigate('/')}
                className="flex-1 h-12 rounded-xl"
              >
                Done
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </Layout>
  );
};

export default RequestPage;