import { motion } from 'framer-motion';
import { useState } from 'react';
import { ArrowLeft, Shield, Clock, Users, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

const SafePayPage = () => {
  const navigate = useNavigate();
  const { safePayMode, setSafePayMode } = useApp();
  const { toast } = useToast();
  
  const [maxAmount, setMaxAmount] = useState(safePayMode.maxAmount.toString());
  const [timeWindow, setTimeWindow] = useState(safePayMode.timeWindow.toString());
  const [contacts, setContacts] = useState(safePayMode.allowedContacts.join(', '));

  const handleSave = () => {
    setSafePayMode({
      enabled: safePayMode.enabled,
      maxAmount: parseFloat(maxAmount) || 1000,
      timeWindow: parseInt(timeWindow) || 24,
      allowedContacts: contacts.split(',').map(c => c.trim()).filter(c => c),
    });

    toast({
      title: 'Settings Saved',
      description: 'Safe Pay Mode has been updated.',
    });
  };

  return (
    <Layout showNav={false}>
      <div className="container mx-auto px-4 py-6">
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-muted-foreground mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </motion.button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl gradient-success flex items-center justify-center shadow-success-glow">
              <Shield className="w-7 h-7 text-success-foreground" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-foreground">Safe Pay Mode</h1>
              <p className="text-muted-foreground">Extra protection for your transactions</p>
            </div>
          </div>

          {/* Enable Toggle */}
          <div className="bg-card rounded-2xl border border-border p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Check className="w-5 h-5 text-success" />
              <div>
                <p className="font-medium text-foreground">Enable Safe Pay Mode</p>
                <p className="text-sm text-muted-foreground">Restrict payments with custom rules</p>
              </div>
            </div>
            <Switch
              checked={safePayMode.enabled}
              onCheckedChange={(enabled) => setSafePayMode({ ...safePayMode, enabled })}
            />
          </div>

          {/* Settings */}
          <div className="space-y-4">
            <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-bold">₹</span>
                </div>
                <div>
                  <p className="font-medium text-foreground">Maximum Amount</p>
                  <p className="text-sm text-muted-foreground">Limit per transaction</p>
                </div>
              </div>
              <Input
                type="number"
                value={maxAmount}
                onChange={(e) => setMaxAmount(e.target.value)}
                placeholder="1000"
                className="h-12 rounded-xl"
              />
            </div>

            <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-warning/10 flex items-center justify-center">
                  <Clock className="w-4 h-4 text-warning" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Time Window</p>
                  <p className="text-sm text-muted-foreground">Hours until reset</p>
                </div>
              </div>
              <Input
                type="number"
                value={timeWindow}
                onChange={(e) => setTimeWindow(e.target.value)}
                placeholder="24"
                className="h-12 rounded-xl"
              />
            </div>

            <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center">
                  <Users className="w-4 h-4 text-success" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Allowed Contacts</p>
                  <p className="text-sm text-muted-foreground">UPI IDs separated by commas</p>
                </div>
              </div>
              <Input
                type="text"
                value={contacts}
                onChange={(e) => setContacts(e.target.value)}
                placeholder="friend@upi, family@upi"
                className="h-12 rounded-xl"
              />
            </div>
          </div>

          <Button
            onClick={handleSave}
            className="w-full h-14 rounded-2xl text-lg gradient-primary"
          >
            Save Settings
          </Button>
        </motion.div>
      </div>
    </Layout>
  );
};

export default SafePayPage;