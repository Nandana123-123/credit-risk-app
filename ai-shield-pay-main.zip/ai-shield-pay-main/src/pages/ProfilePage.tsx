import { motion } from 'framer-motion';
import { User, Moon, Sun, Shield, HelpCircle, LogOut, ChevronRight, Bell, Lock } from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { useApp } from '@/contexts/AppContext';
import { Switch } from '@/components/ui/switch';

const ProfilePage = () => {
  const { darkMode, setDarkMode } = useApp();

  const menuItems = [
    { icon: Shield, label: 'Security Settings', description: 'PIN, biometrics, and more' },
    { icon: Bell, label: 'Notifications', description: 'Manage alerts and updates' },
    { icon: Lock, label: 'Privacy', description: 'Data and permissions' },
    { icon: HelpCircle, label: 'Help & Support', description: 'FAQs and contact us' },
    { icon: LogOut, label: 'Sign Out', description: 'Log out of your account', danger: true },
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <div className="w-24 h-24 rounded-3xl gradient-primary flex items-center justify-center mx-auto shadow-glow">
            <User className="w-12 h-12 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-foreground">Demo User</h1>
            <p className="text-muted-foreground">demo@rakshapay.ai</p>
          </div>
        </motion.div>

        {/* Dark Mode Toggle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-2xl border border-border p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            {darkMode ? <Moon className="w-5 h-5 text-primary" /> : <Sun className="w-5 h-5 text-warning" />}
            <div>
              <p className="font-medium text-foreground">Dark Mode</p>
              <p className="text-sm text-muted-foreground">Toggle app appearance</p>
            </div>
          </div>
          <Switch
            checked={darkMode}
            onCheckedChange={setDarkMode}
          />
        </motion.div>

        {/* Menu Items */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-2xl border border-border divide-y divide-border"
        >
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.label}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + index * 0.05 }}
                className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors text-left"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  item.danger ? 'bg-danger/10' : 'bg-primary/10'
                }`}>
                  <Icon className={`w-5 h-5 ${item.danger ? 'text-danger' : 'text-primary'}`} />
                </div>
                <div className="flex-1">
                  <p className={`font-medium ${item.danger ? 'text-danger' : 'text-foreground'}`}>
                    {item.label}
                  </p>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </motion.button>
            );
          })}
        </motion.div>

        {/* Version */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-center text-sm text-muted-foreground"
        >
          RakshaPay AI v1.0.0 - Demo Build
        </motion.p>
      </div>
    </Layout>
  );
};

export default ProfilePage;