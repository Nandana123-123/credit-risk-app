import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, User, MapPin, AlertTriangle, Check, X, Brain, Shield, Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FraudMeter } from '@/components/ui/FraudMeter';
import { RiskBadge } from '@/components/ui/RiskBadge';
import { TransactionAnalysisPopup } from '@/components/pay/RiskPopups';
import { WarningPopup, FraudEducationCard, type WarningType } from '@/components/pay/WarningPopups';
import { SecurityPasswordSetup } from '@/components/security/SecurityPasswordSetup';
import { PinInput } from '@/components/pay/PinInput';
import { XAIPanel } from '@/components/xai/XAIPanel';
import { useApp } from '@/contexts/AppContext';
import type { RiskLevel, Transaction } from '@/contexts/AppContext';
import { toast } from 'sonner';

type PayStep = 'upi' | 'password' | 'receiver' | 'amount' | 'analysis' | 'review' | 'pin' | 'result';

interface WarningItem {
  type: WarningType;
  canProceed: boolean;
}

const PayPage = () => {
  const navigate = useNavigate();
  const { demoMode, balance, setBalance, addTransaction, isPasswordSet, securityPassword, setSecurityPassword } = useApp();
  
  const [step, setStep] = useState<PayStep>('upi');
  const [upiId, setUpiId] = useState('');
  const [password, setPassword] = useState('');
  const [amount, setAmount] = useState('');
  const [showPasswordSetup, setShowPasswordSetup] = useState(false);
  const [showWarningPopup, setShowWarningPopup] = useState(false);
  const [showAnalysisPopup, setShowAnalysisPopup] = useState(false);
  const [showXAI, setShowXAI] = useState(false);
  const [showEducation, setShowEducation] = useState(false);
  const [currentWarning, setCurrentWarning] = useState<WarningItem | null>(null);
  const [warningQueue, setWarningQueue] = useState<WarningItem[]>([]);
  const [transactionResult, setTransactionResult] = useState<'success' | 'blocked' | null>(null);
  const [newTransaction, setNewTransaction] = useState<Transaction | null>(null);
  const [passwordError, setPasswordError] = useState('');

  // Check if password needs to be set up
  useEffect(() => {
    if (!isPasswordSet) {
      setShowPasswordSetup(true);
    }
  }, [isPasswordSet]);

  // Mock receiver data based on demo mode
  const getReceiverData = () => {
    if (demoMode === 'fraudster') {
      return {
        name: 'Investment Scheme XYZ',
        verified: false,
        location: 'Unknown Location',
        riskLevel: 'blocked' as RiskLevel,
        fraudProbability: 92,
      };
    }
    if (demoMode === 'victim') {
      return {
        name: 'Tech Support Agent',
        verified: false,
        location: 'Suspicious IP - Foreign',
        riskLevel: 'suspicious' as RiskLevel,
        fraudProbability: 68,
      };
    }
    return {
      name: 'Rahul Sharma',
      verified: true,
      location: 'Mumbai, Maharashtra',
      riskLevel: 'safe' as RiskLevel,
      fraudProbability: 5,
    };
  };

  const receiver = getReceiverData();

  // Calculate real-time risk
  const calculateRisk = () => {
    const amountNum = parseFloat(amount) || 0;
    let riskFactors = {
      behaviour: 5,
      amountAnomaly: 0,
      deviceRisk: 5,
      graphRisk: 0,
      voiceNlpRisk: 0,
    };

    if (demoMode === 'fraudster') {
      riskFactors = { behaviour: 30, amountAnomaly: 25, deviceRisk: 15, graphRisk: 12, voiceNlpRisk: 10 };
    } else if (demoMode === 'victim') {
      riskFactors = { behaviour: 20, amountAnomaly: 20, deviceRisk: 12, graphRisk: 8, voiceNlpRisk: 8 };
    } else {
      riskFactors.amountAnomaly = amountNum > 20000 ? 35 : amountNum > 10000 ? 25 : amountNum > 2000 ? 15 : amountNum > 500 ? 8 : 2;
    }

    return riskFactors;
  };

  const getRiskLevel = (): RiskLevel => {
    if (demoMode === 'fraudster') return 'blocked';
    if (demoMode === 'victim') return 'suspicious';
    const amountNum = parseFloat(amount) || 0;
    if (amountNum > 20000) return 'suspicious';
    if (amountNum > 10000) return 'suspicious';
    return 'safe';
  };

  // Generate comprehensive warnings based on all risk factors
  const generateWarnings = (): WarningItem[] => {
    const warnings: WarningItem[] = [];
    const amountNum = parseFloat(amount) || 0;
    const currentHour = new Date().getHours();

    // Amount-based warnings
    if (amountNum >= 500 && amountNum < 2000) {
      warnings.push({ type: 'unusual_amount', canProceed: true });
    }

    if (amountNum >= 2000 && amountNum < 20000) {
      warnings.push({ type: 'high_value', canProceed: true });
    }

    // Very high value warning (>₹20,000)
    if (amountNum >= 20000) {
      warnings.push({ type: 'very_high_value', canProceed: true });
    }

    // Late night transaction warning
    if (currentHour >= 23 || currentHour <= 5) {
      warnings.push({ type: 'night_transaction', canProceed: true });
    }

    // Demo mode specific warnings
    if (demoMode === 'victim') {
      warnings.push({ type: 'unknown_receiver', canProceed: true });
      warnings.push({ type: 'location_mismatch', canProceed: true });
      warnings.push({ type: 'behavioral_anomaly', canProceed: true });
      warnings.push({ type: 'victim_detected', canProceed: false });
    }

    if (demoMode === 'fraudster') {
      warnings.push({ type: 'unknown_receiver', canProceed: false });
      warnings.push({ type: 'location_mismatch', canProceed: false });
      warnings.push({ type: 'fraud_detected', canProceed: false });
    }

    return warnings;
  };

  const handlePasswordSetupComplete = (newPassword: string) => {
    setSecurityPassword(newPassword);
    setShowPasswordSetup(false);
    toast.success('Security password created successfully!');
  };

  const handleUpiSubmit = () => {
    if (upiId.includes('@')) {
      setStep('password');
    }
  };

  const handlePasswordSubmit = () => {
    if (password !== securityPassword) {
      setPasswordError('Incorrect security password');
      return;
    }
    setPasswordError('');
    setStep('receiver');
  };

  const handleReceiverConfirm = () => {
    setStep('amount');
  };

  const handleAmountSubmit = () => {
    const warnings = generateWarnings();
    if (warnings.length > 0) {
      setWarningQueue(warnings);
      setCurrentWarning(warnings[0]);
      setShowWarningPopup(true);
    } else {
      setStep('analysis');
      setTimeout(() => setShowAnalysisPopup(true), 500);
    }
  };

  const handleWarningContinue = () => {
    setShowWarningPopup(false);
    
    // Check if current warning blocks the transaction
    if (currentWarning && !currentWarning.canProceed) {
      completeTransaction('blocked');
      return;
    }

    const remainingWarnings = warningQueue.slice(1);
    if (remainingWarnings.length > 0) {
      setWarningQueue(remainingWarnings);
      setCurrentWarning(remainingWarnings[0]);
      setTimeout(() => setShowWarningPopup(true), 300);
    } else {
      setStep('analysis');
      setTimeout(() => setShowAnalysisPopup(true), 500);
    }
  };

  const handleWarningClose = () => {
    setShowWarningPopup(false);
    
    // If it's a blocking warning, show education and block
    if (currentWarning && !currentWarning.canProceed) {
      setShowEducation(true);
    } else {
      setStep('amount');
    }
  };

  const handleAnalysisProceed = () => {
    setShowAnalysisPopup(false);
    if (getRiskLevel() === 'blocked') {
      completeTransaction('blocked');
    } else {
      setStep('review');
    }
  };

  const handleReviewConfirm = () => {
    setStep('pin');
  };

  const handlePinComplete = (pin: string) => {
    completeTransaction(getRiskLevel() === 'blocked' ? 'blocked' : 'success');
  };

  const completeTransaction = (result: 'success' | 'blocked') => {
    const transaction: Transaction = {
      id: Date.now().toString(),
      type: 'sent',
      amount: parseFloat(amount),
      name: receiver.name,
      upiId: upiId,
      date: new Date(),
      riskLevel: getRiskLevel(),
      fraudProbability: receiver.fraudProbability,
      status: result === 'blocked' ? 'blocked' : 'completed',
      riskFactors: calculateRisk(),
    };

    setNewTransaction(transaction);
    addTransaction(transaction);
    
    if (result === 'success') {
      setBalance(balance - parseFloat(amount));
    }

    if (result === 'blocked') {
      setShowEducation(true);
    }

    setTransactionResult(result);
    setStep('result');
  };

  const renderStep = () => {
    switch (step) {
      case 'upi':
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">Pay Anyone</h2>
              <p className="text-muted-foreground">Enter UPI ID or phone number</p>
            </div>

            <div className="space-y-4">
              <Input
                type="text"
                placeholder="example@upi"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="h-14 text-lg text-center rounded-2xl"
              />

              <Button
                onClick={handleUpiSubmit}
                disabled={!upiId.includes('@')}
                className="w-full h-14 rounded-2xl text-lg gradient-primary"
              >
                Continue
              </Button>
            </div>
          </motion.div>
        );

      case 'password':
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 10 }}
                className="w-20 h-20 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4"
              >
                <Lock className="w-10 h-10 text-primary-foreground" />
              </motion.div>
              <h2 className="font-display text-2xl font-bold text-foreground">Security Verification</h2>
              <p className="text-muted-foreground">Enter your security password to continue</p>
            </div>

            <div className="space-y-4">
              <Input
                type="password"
                placeholder="Enter security password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setPasswordError('');
                }}
                className="h-14 text-lg text-center rounded-2xl"
              />

              {passwordError && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 p-3 rounded-xl bg-danger/10 border border-danger/20"
                >
                  <AlertTriangle className="w-4 h-4 text-danger" />
                  <span className="text-sm text-danger">{passwordError}</span>
                </motion.div>
              )}

              <Button
                onClick={handlePasswordSubmit}
                disabled={password.length < 6}
                className="w-full h-14 rounded-2xl text-lg gradient-primary"
              >
                Verify & Continue
              </Button>
            </div>

            <div className="flex items-start gap-2 p-4 rounded-xl bg-primary/5 border border-primary/10">
              <Shield className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                This extra layer of security helps protect you from unauthorized transactions
              </p>
            </div>
          </motion.div>
        );

      case 'receiver':
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">Verify Receiver</h2>
              <p className="text-muted-foreground">Please confirm the receiver details</p>
            </div>

            <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <User className="w-8 h-8 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-lg font-semibold text-foreground">{receiver.name}</h3>
                    {receiver.verified && <Check className="w-5 h-5 text-success" />}
                  </div>
                  <p className="text-sm text-muted-foreground">{upiId}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-muted/50">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">{receiver.location}</span>
              </div>

              <RiskBadge level={receiver.riskLevel} size="lg" className="w-full justify-center" />
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep('upi')} className="flex-1 h-12 rounded-xl">
                Change
              </Button>
              <Button onClick={handleReceiverConfirm} className="flex-1 h-12 rounded-xl gradient-primary">
                Confirm
              </Button>
            </div>
          </motion.div>
        );

      case 'amount':
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">Enter Amount</h2>
              <p className="text-muted-foreground">Paying to {receiver.name}</p>
            </div>

            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl text-muted-foreground">₹</span>
              <Input
                type="number"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="h-20 text-4xl font-display font-bold text-center rounded-2xl pl-10"
              />
            </div>

            {amount && parseFloat(amount) > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-3"
              >
                <FraudMeter 
                  probability={Math.min(95, receiver.fraudProbability + (parseFloat(amount) > 20000 ? 30 : parseFloat(amount) > 2000 ? 20 : 0))} 
                  animated 
                />
                
                {parseFloat(amount) >= 20000 && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-2 p-3 rounded-xl bg-warning/10 border border-warning/20"
                  >
                    <AlertTriangle className="w-5 h-5 text-warning" />
                    <span className="text-sm text-warning font-medium">High value: Extra verification required</span>
                  </motion.div>
                )}
              </motion.div>
            )}

            <Button
              onClick={handleAmountSubmit}
              disabled={!amount || parseFloat(amount) <= 0}
              className="w-full h-14 rounded-2xl text-lg gradient-primary"
            >
              Continue
            </Button>
          </motion.div>
        );

      case 'analysis':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-12 space-y-6"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              className="w-20 h-20 rounded-2xl gradient-primary flex items-center justify-center"
            >
              <Brain className="w-10 h-10 text-primary-foreground" />
            </motion.div>
            <div className="text-center space-y-2">
              <h2 className="font-display text-xl font-bold text-foreground">Analyzing Transaction</h2>
              <p className="text-muted-foreground">AI is checking for fraud patterns...</p>
            </div>
          </motion.div>
        );

      case 'review':
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">Review & Pay</h2>
              <p className="text-muted-foreground">Verify all details before proceeding</p>
            </div>

            <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Paying to</span>
                <span className="font-semibold text-foreground">{receiver.name}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">UPI ID</span>
                <span className="font-mono text-foreground">{upiId}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-display text-2xl font-bold text-foreground">₹{parseFloat(amount).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Risk Status</span>
                <RiskBadge level={getRiskLevel()} />
              </div>
            </div>

            <Button
              onClick={handleReviewConfirm}
              className="w-full h-14 rounded-2xl text-lg gradient-primary"
            >
              Proceed to PIN
            </Button>
          </motion.div>
        );

      case 'pin':
        return (
          <PinInput
            onComplete={handlePinComplete}
            onCancel={() => setStep('review')}
            disabled={getRiskLevel() === 'blocked'}
          />
        );

      case 'result':
        return (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center py-12 space-y-6"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', damping: 15 }}
              className={`w-24 h-24 rounded-3xl flex items-center justify-center ${
                transactionResult === 'success' ? 'gradient-success shadow-success-glow' : 'gradient-danger shadow-danger-glow'
              }`}
            >
              {transactionResult === 'success' ? (
                <Check className="w-12 h-12 text-success-foreground" />
              ) : (
                <X className="w-12 h-12 text-danger-foreground" />
              )}
            </motion.div>

            <div className="text-center space-y-2">
              <h2 className="font-display text-2xl font-bold text-foreground">
                {transactionResult === 'success' ? 'Payment Successful!' : 'Transaction Blocked'}
              </h2>
              <p className="text-muted-foreground">
                {transactionResult === 'success' 
                  ? `₹${parseFloat(amount).toLocaleString('en-IN')} sent to ${receiver.name}`
                  : 'Our AI detected potential fraud and protected your money'}
              </p>
            </div>

            {transactionResult === 'blocked' && (
              <Button
                variant="outline"
                onClick={() => setShowXAI(true)}
                className="gap-2"
              >
                <Brain className="w-4 h-4" />
                View AI Reasoning
              </Button>
            )}

            <Button
              onClick={() => navigate('/')}
              className="w-full h-14 rounded-2xl text-lg"
            >
              Back to Home
            </Button>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <Layout showNav={false}>
      <div className="container mx-auto px-4 py-6 min-h-screen">
        {step !== 'result' && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={() => step === 'upi' ? navigate(-1) : setStep('upi')}
            className="flex items-center gap-2 text-muted-foreground mb-6"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </motion.button>
        )}

        {renderStep()}
      </div>

      {/* Security Password Setup Modal */}
      <SecurityPasswordSetup
        isOpen={showPasswordSetup}
        onComplete={handlePasswordSetupComplete}
      />

      {/* Warning Popups */}
      {currentWarning && (
        <WarningPopup
          isOpen={showWarningPopup}
          onClose={handleWarningClose}
          onContinue={handleWarningContinue}
          warningType={currentWarning.type}
          receiverName={receiver.name}
          amount={parseFloat(amount)}
          canProceed={currentWarning.canProceed}
        />
      )}

      {/* Transaction Analysis Popup */}
      <TransactionAnalysisPopup
        isOpen={showAnalysisPopup}
        onClose={() => {
          setShowAnalysisPopup(false);
          setStep('amount');
        }}
        onProceed={handleAnalysisProceed}
        fraudProbability={receiver.fraudProbability}
        riskLevel={getRiskLevel()}
        riskFactors={calculateRisk()}
      />

      {/* Fraud Education Card */}
      <FraudEducationCard
        isOpen={showEducation}
        onClose={() => setShowEducation(false)}
        warningType={currentWarning?.type || 'fraud_detected'}
      />

      {/* XAI Panel for blocked transactions */}
      {newTransaction && (
        <XAIPanel
          isOpen={showXAI}
          onClose={() => setShowXAI(false)}
          transaction={newTransaction}
        />
      )}
    </Layout>
  );
};

export default PayPage;